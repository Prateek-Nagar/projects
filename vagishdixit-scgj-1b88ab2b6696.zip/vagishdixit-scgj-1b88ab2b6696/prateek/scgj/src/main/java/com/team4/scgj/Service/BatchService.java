package com.team4.scgj.Service;

import com.team4.scgj.Entity.Batch;
import com.team4.scgj.Repository.IBatchRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BatchService {

    @Autowired
    IBatchRepository iBatchRepository;

    public List<Batch> getBatchList() {

        return (List<Batch>) iBatchRepository.findAll();

    }
}
