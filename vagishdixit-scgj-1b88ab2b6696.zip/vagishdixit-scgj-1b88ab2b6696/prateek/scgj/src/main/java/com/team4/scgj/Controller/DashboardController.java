package com.team4.scgj.Controller;


import com.team4.scgj.Service.DashBoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller(value = "dashboardController")
@RequestMapping("/scgj")
public class DashboardController {


    @Autowired
    DashBoardService dashBoardService;


    @RequestMapping("/dashboard")
    ModelAndView getForm() {

        ModelAndView modelAndView = new ModelAndView("index");

        int candidatesCertified = dashBoardService.getEnrolledNumber();
        int candidatedAssessed = dashBoardService.getAssessedNumber();
        int totalTrainingCenter = dashBoardService.getTrainingCenterCount();
        int totalTrainingPartner = dashBoardService.getTrainingPartner();

        modelAndView.addObject("certified", candidatesCertified);
        modelAndView.addObject("assessed", candidatedAssessed);
        modelAndView.addObject("totalTP", totalTrainingCenter);
        modelAndView.addObject("totalTC", totalTrainingPartner);


        return modelAndView;
    }
}
