package com.team4.scgj.Service;



import com.team4.scgj.Entity.User;
import com.team4.scgj.Repository.SignUpRepository;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SignUpService {

    @Autowired
    SignUpRepository signUpRepository;
/*

    @Autowired
    private PasswordEncoder passwordEncoder;
*/

    public void saveUser(User responseData)
    {
       // responseData.setUserPassword(new BCryptPasswordEncoder().encode(responseData.getUserPassword()));
        signUpRepository.save(responseData);
    }

    public List<User> checkUser(User responseData) {

        return signUpRepository.findByUserName(responseData.getUserName());
    }
}
