package com.team4.scgj.Entity;


import javax.persistence.*;

@Entity
@Table(name = "assessor")
public class Assessor {

    @Id
    @Column(name = "assessor_id")
    private int assessorId;

    public Assessor() {
    }

    @Column(name = "assessor_name")

    private String assessorName;


    @OneToOne
    @JoinColumn(name = "location_id")
    private Location locationId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assessment_body_id")
    private AssessmentBody assessmentBodyId;

    public int getAssessorId() {
        return assessorId;
    }

    public void setAssessorId(int assessorId) {
        this.assessorId = assessorId;
    }

    public String getAssessorName() {
        return assessorName;
    }

    public void setAssessorName(String assessorName) {
        this.assessorName = assessorName;
    }

    public Location getLocationId() {
        return locationId;
    }

    public void setLocationId(Location locationId) {
        this.locationId = locationId;
    }

    public AssessmentBody getAssessmentBodyId() {
        return assessmentBodyId;
    }

    public void setAssessmentBodyId(AssessmentBody assessmentBodyId) {
        this.assessmentBodyId = assessmentBodyId;
    }
}
