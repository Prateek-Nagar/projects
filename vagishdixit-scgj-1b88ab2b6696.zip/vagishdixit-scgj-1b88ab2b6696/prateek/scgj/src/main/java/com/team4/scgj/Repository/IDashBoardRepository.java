package com.team4.scgj.Repository;

import com.team4.scgj.Entity.Batch;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IDashBoardRepository extends CrudRepository<Batch, Integer> {


    @Query("SELECT SUM(u.totalCertified) from Batch u")
    int getTotalCertifed();

    @Query("Select sum(u.totalAppeared) from Batch u")
    int getTotalAssessed();

    @Query("select count(t) from TrainingCenter t")
    int getTainingCenterCount();

    @Query("select count(tp) from TrainingPartner tp")
    int getTrainingPartnerCount();
}
