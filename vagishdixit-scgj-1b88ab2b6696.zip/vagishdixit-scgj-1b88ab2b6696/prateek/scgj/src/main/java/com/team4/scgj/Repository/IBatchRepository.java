package com.team4.scgj.Repository;

import com.team4.scgj.Entity.Batch;
import org.springframework.data.repository.CrudRepository;

public interface IBatchRepository extends CrudRepository<Batch, Integer> {
}
