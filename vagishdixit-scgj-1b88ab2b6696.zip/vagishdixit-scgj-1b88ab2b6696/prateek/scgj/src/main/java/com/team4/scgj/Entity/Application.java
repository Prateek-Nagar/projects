package com.team4.scgj.Entity;


import javax.persistence.*;

@Entity
@Table(name = "application")
public class Application {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int applicationId;

    @Column(name = "status")
    private
    String status;

    public Application() {
    }


    @Column(name = "form_status")
    private boolean formStatus;

    public Application(int userId) {
        this.userId.setUserId(userId);
    }

    public boolean isFormStatus() {
        return formStatus;
    }

    public void setFormStatus(boolean formStatus) {
        this.formStatus = formStatus;
    }

    @Column(name = "comment")
    private String comment;

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    @OneToOne
    @JoinColumn(name = "user_id")
    private User userId;

    public int getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(int applicationId) {
        this.applicationId = applicationId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public User getUserId() {
        return userId;
    }

    public void setUserId(User userId) {
        this.userId = userId;
    }
}
