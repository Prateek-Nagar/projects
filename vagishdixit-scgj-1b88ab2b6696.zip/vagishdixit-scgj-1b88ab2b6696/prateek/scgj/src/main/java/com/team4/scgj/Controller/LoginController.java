package com.team4.scgj.Controller;

import com.team4.scgj.Entity.User;
import com.team4.scgj.Service.LoginService;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
//@SessionAttributes("userName")
@RequestMapping("/log")
public class LoginController {

    @Autowired
    LoginService loginService;

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    ModelAndView getLogin() {
        ModelAndView modelAndView = new ModelAndView("login");
        modelAndView.addObject("login", new User());
        return modelAndView;
    }


    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public ModelAndView formSucess(@ModelAttribute User responseData, HttpServletRequest request, HttpServletResponse response) {
        ModelAndView modelAndView = null;

        User loginStatus=loginService.validateUser(responseData);
        if (loginStatus == null) return modelAndView.addObject("error", "username not exist");
        else {
            if (loginStatus.getUserType().equals("Admin")) {
                modelAndView = new ModelAndView("redirect:/scgj/dashboard");
                modelAndView.addObject("userName", responseData.getUserName());
                System.out.println(responseData.getUserName());
                //session.setAttribute("loggedInUser",loginStatus);
                return modelAndView;
            } else if (loginStatus.getUserType().equals("TP")) {
                return new ModelAndView("redirect:/tp/tpform");
            } else if (loginStatus.getUserType().equals("AssessmentBody")) {
                return new ModelAndView("redirect:/ab/abform");
            }
        }
        return modelAndView;
    }



   /* @RequestMapping(value="/logout",method=RequestMethod.GET)
    public String logout(HttpSession session)
    {
        session.removeAttribute("loggedInUser");
        return"login";
    }*/

}
