package com.team4.scgj.Controller;


import com.team4.scgj.Entity.User;
import com.team4.scgj.Service.SignUpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class SignUpController {


    @Autowired
    SignUpService signUpService;

    @RequestMapping("/signup")
    ModelAndView signUp() {
        ModelAndView modelAndView = new ModelAndView("welcome");
        modelAndView.addObject("user", new User());
        return modelAndView;
    }

    @RequestMapping(value = "/signup", method = RequestMethod.POST)
    public ModelAndView formSucess(@ModelAttribute User responseData) {
        ModelAndView modelAndView = new ModelAndView("welcome");

        List<User> userCheck = signUpService.checkUser(responseData);
        if (!(userCheck.size()>0)) {
            signUpService.saveUser(responseData);
            return new ModelAndView("redirect:/log/login");
        }
        else
        {
            return modelAndView.addObject("error","username already exists");
            //System.out.println("Username exists");
        }

    }


}
