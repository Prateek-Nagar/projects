package com.team4.scgj.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/ab")
public class AssessmentBodyController {

    @RequestMapping("/abform")
    ModelAndView getForm() {
        return new ModelAndView("ABForm");
    }
}
