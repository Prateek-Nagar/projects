package com.team4.scgj.Service;


import com.team4.scgj.Repository.IDashBoardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DashBoardService {

    @Autowired
    IDashBoardRepository iDashBoardRepository;


    public int getEnrolledNumber() {
        return iDashBoardRepository.getTotalCertifed();
    }

    public int getAssessedNumber() {
        return iDashBoardRepository.getTotalAssessed();
    }

    public int getTrainingCenterCount() {
        return iDashBoardRepository.getTainingCenterCount();
    }

    public int getTrainingPartner() {
        return iDashBoardRepository.getTrainingPartnerCount();
    }
}
