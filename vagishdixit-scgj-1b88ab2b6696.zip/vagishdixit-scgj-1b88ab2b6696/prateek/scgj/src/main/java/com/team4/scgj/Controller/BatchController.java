package com.team4.scgj.Controller;

import com.team4.scgj.Entity.Batch;
import com.team4.scgj.Service.BatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class BatchController {

    @Autowired
    BatchService batchService;

    @RequestMapping("/getBatch")
    @ResponseBody
    public ModelAndView getBatch() {
        List<Batch> batchList = batchService.getBatchList();
        ModelAndView modelAndView = new ModelAndView("batch");
        modelAndView.addObject("data", batchList);
        return modelAndView;
    }


}
