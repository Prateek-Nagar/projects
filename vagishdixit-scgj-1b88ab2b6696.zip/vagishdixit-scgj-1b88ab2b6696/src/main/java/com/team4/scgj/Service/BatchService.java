
package com.team4.scgj.Service;

import com.team4.scgj.Entity.AssessmentBody;
import com.team4.scgj.Entity.Batch;
import com.team4.scgj.Repository.CandidateRepository;
import com.team4.scgj.Repository.IAssessmentBodyRepository;
import com.team4.scgj.Repository.IBatchRepository;
import com.team4.scgj.Repository.ITCRepository;
import com.team4.scgj.enums.BatchStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

import static org.springframework.data.repository.init.ResourceReader.Type.JSON;
import com.team4.scgj.Entity.AssessmentBody;
import com.team4.scgj.Entity.Batch;
import com.team4.scgj.Entity.Location;
import com.team4.scgj.Repository.IAssessmentBodyRepository;
import com.team4.scgj.Repository.IBatchRepository;
import com.team4.scgj.enums.BatchStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class BatchService {

    @Autowired
    private IBatchRepository iBatchRepository;

    @Autowired
    private IAssessmentBodyRepository iAssessmentBodyRepository;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    ITCRepository itcRepository;

    @Autowired
    CandidateRepository candidateRepository;

    public List<Batch> getBatchList() {

        return (List<Batch>) iBatchRepository.findAll();

    }

    public int getCertified() {
        return iBatchRepository.getTotalCertifed();
    }

    public int getAssessed() {
        return iBatchRepository.getTotalAssessed();
    }

    public int getCertifiedMode(String batchMode) {
        return iBatchRepository.getTotalCertifedMode(batchMode);
    }

    public int getAssessedMode(String batchMode) {
        return iBatchRepository.getTotalAssessedMode(batchMode);
    }


    public List<Batch> getNonAssignedBatch() {
        return iBatchRepository.getNonAssignedBatch();
    }


    public String getStatus(int id) {
        return iBatchRepository.batchName(id);

    }


    public List<Integer> getABCD() {
        return iBatchRepository.getAb();
    }

    public int getElevenData(int id) {
        return iBatchRepository.getElevenData(id);
    }





    public String getAgencyName(int id) {
        String agencyName = null;
        String query = "select assessment_body_name as nameAgency from batch,assessment_body where assessment_body.assessment_id = batch.assessment_body_id and batch.batch_id =?";
        try {
            PreparedStatement statement = jdbcTemplate.getDataSource().getConnection().prepareStatement(query);
            statement.setInt(1, id);
            ResultSet count = statement.executeQuery();
            while (count.next()) {
                agencyName = count.getString("nameAgency");
            }

        } catch (Exception e) {

        }
        return agencyName;
    }

    public Map<Integer, Integer> getBatchCandidateCount() {
        Map<Integer, Integer> map = new HashMap<>();
        String query = "select batch.batch_id as batchId,count(candidate_id) as numberOfCandidates from candidate,batch where batch.batch_id = candidate.batch_id and year(batch_start_date) >2014 group by batch.batch_id";
        try {
            PreparedStatement statement = jdbcTemplate.getDataSource().getConnection().prepareStatement(query);
            ResultSet count = statement.executeQuery();
            while (count.next()) {
//                map as JSON
                map.put(count.getInt("batchId"), count.getInt("numberOfCandidates"));

            }

        } catch (Exception e) {

        }
        return map;
    }



    public List<Batch> getBatchList(BatchStatus batchStatus){
        List<Batch> listOfUsers =iBatchRepository.findAllByBatchStatus(batchStatus);
        return listOfUsers;
    }

    public void saveBatchAndAssessmentBody(){

        AssessmentBody assessmentBody = new AssessmentBody();
        assessmentBody.setAssessmentBodyId(1);
        assessmentBody.setAssessmentBodyName("Federation of Indian Woman Enterpreneurs (FIWE)");
        iAssessmentBodyRepository.save(assessmentBody);

         AssessmentBody assessmentBody1 = new AssessmentBody();
        assessmentBody1.setAssessmentBodyId(2);
        assessmentBody1.setAssessmentBodyName("Trendsetters Skill Assessors");
        iAssessmentBodyRepository.save(assessmentBody1);

         AssessmentBody assessmentBody2 = new AssessmentBody();
        assessmentBody2.setAssessmentBodyId(3);
        assessmentBody2.setAssessmentBodyName("Own Assessments Pvt. Ltd");
        iAssessmentBodyRepository.save(assessmentBody2);

        AssessmentBody assessmentBody3 = new AssessmentBody();
        assessmentBody3.setAssessmentBodyId(4);
        assessmentBody3.setAssessmentBodyName("Centurion Assessments Pvt. Ltd");
        iAssessmentBodyRepository.save(assessmentBody3);

        Batch batch= new Batch();
        batch.setBatchEndDate(new Date());
        batch.setAssessmentDate(new Date());
        batch.setAssessmentBodyId(assessmentBody1);
        batch.setBatchStatus(BatchStatus.PENDING);
        iBatchRepository.save(batch);

        System.out.println("1");

        Batch batch1= new Batch();
        batch1.setBatchEndDate(new Date());
        batch1.setAssessmentDate(new Date());
        batch1.setAssessmentBodyId(assessmentBody);
        batch1.setBatchStatus(BatchStatus.PENDING);
        iBatchRepository.save(batch1);

        System.out.println("2");

        Batch batch2= new Batch();
        batch2.setBatchEndDate(new Date());
        //batch2.setLocation_id(1);
        batch2.setAssessmentDate(new Date());
        batch2.setAssessmentBodyId(assessmentBody2);
        batch2.setBatchStatus(BatchStatus.PENDING);
        iBatchRepository.save(batch2);

        System.out.println("3");

        Batch batch3= new Batch();
        batch3.setBatchEndDate(new Date());
        //batch2.setLocation_id(1);
        batch3.setAssessmentDate(new Date());
        batch3.setBatchStatus(BatchStatus.APPROVED);
        batch3.setAssessmentBodyId(assessmentBody3);
        iBatchRepository.save(batch3);

        Batch batch4= new Batch();
        batch4.setBatchEndDate(new Date());
        //batch2.setLocation_id(1);
        batch4.setAssessmentBodyId(assessmentBody);
        batch4.setAssessmentDate(new Date());
        batch4.setBatchStatus(BatchStatus.REJECTED);
        iBatchRepository.save(batch4);

        Batch batch5= new Batch();
        batch5.setBatchEndDate(new Date());
        //batch2.setLocation_id(1);
        batch5.setAssessmentBodyId(assessmentBody1);
        batch5.setAssessmentDate(new Date());
        batch5.setBatchStatus(BatchStatus.REJECTED);
        iBatchRepository.save(batch5);

        Batch batch6= new Batch();
        batch6.setBatchEndDate(new Date());
        //batch2.setLocation_id(1);
        batch6.setAssessmentDate(new Date());
        batch6.setAssessmentBodyId(assessmentBody3);
        batch6.setBatchStatus(BatchStatus.APPROVED);
        iBatchRepository.save(batch6);

        Batch batch7= new Batch();
        batch7.setBatchEndDate(new Date());
        //batch2.setLocation_id(1);
        batch7.setAssessmentBodyId(assessmentBody2);
        batch7.setAssessmentDate(new Date());
        batch7.setBatchStatus(BatchStatus.REJECTED);
        iBatchRepository.save(batch7);
    }
}

