package com.team4.scgj.Entity;


import javax.persistence.*;

@Entity
@Table(name="Forms")
public class Forms {

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id")
    private User userId;

    public User getUserId() {
        return userId;
    }

    public void setUserId(User userId) {
        this.userId = userId;
    }

    public int getFormsId() {
        return formsId;
    }

    public void setFormsId(int formsId) {
        this.formsId = formsId;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="forms_id")
    private int formsId;
    @Column(name="organization_name")
    private String organizationName;
    @Column(name="SPOC_name")
    private String SPOCName;
    @Column(name="adress")
    private String address;
    @Column(name="city")
    private String city;
    @Column(name="state")
    private String state;
    @Column(name="pin_code")
    private String  pinCode ;
    @Column(name="mobile_number")
    private int mobileNumber;
    @Column(name="landline_number")
    private String landlineNumber;
    @Column(name="fax_no")
    private String faxNo;
    @Column(name="website")
    private String website;
    @Column(name="year_of_establishment")
    private String yearOfEstablishment;
    @Column(name="qualification_packs")
    private String qualificationPacks;
    @Column(name="is_institution_NSDC_funded")
    private boolean isInstitutionNSDCFunded;
    @Column(name="total_center")
    private int totalCenter;
    @Column(name="PAN")
    private String PAN;
    @Column(name="TAN")
    private String TAN;
    @Column(name="turnover")
    private int turnover;
    @Column(name="experience_of_institute")
    private int experienceOfInstitute;
    @Column(name="name_of_center")
    private String nameOfCenter;
    @Column(name="office_manager_phone_number")
    private int officeManagerPhoneNumber;
    @Column(name="office_staff_phone_number")
    private int officeStaffPhoneNumber;
    @Column(name="lab_attendents_phone_number")
    private int labAttendentsPhoneNumber;
    @Column(name="accountant_phone_number")
    private int accountantPhoneNumber;
    @Column(name="support_staff_phone_number")
    private int supportStaffPhoneNumber;
    @Column(name="others_phone_number")
    private int othersPhoneNumber;

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public String getSPOCName() {
        return SPOCName;
    }

    public void setSPOCName(String SPOCName) {
        this.SPOCName = SPOCName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public int getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(int mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getLandlineNumber() {
        return landlineNumber;
    }

    public void setLandlineNumber(String landlineNumber) {
        this.landlineNumber = landlineNumber;
    }

    public String getFaxNo() {
        return faxNo;
    }

    public void setFaxNo(String faxNo) {
        this.faxNo = faxNo;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getYearOfEstablishment() {
        return yearOfEstablishment;
    }

    public void setYearOfEstablishment(String yearOfEstablishment) {
        this.yearOfEstablishment = yearOfEstablishment;
    }

    public String getQualificationPacks() {
        return qualificationPacks;
    }

    public void setQualificationPacks(String qualificationPacks) {
        this.qualificationPacks = qualificationPacks;
    }

    public boolean isInstitutionNSDCFunded() {
        return isInstitutionNSDCFunded;
    }

    public void setInstitutionNSDCFunded(boolean institutionNSDCFunded) {
        isInstitutionNSDCFunded = institutionNSDCFunded;
    }

    public int getTotalCenter() {
        return totalCenter;
    }

    public void setTotalCenter(int totalCenter) {
        this.totalCenter = totalCenter;
    }

    public String getPAN() {
        return PAN;
    }

    public void setPAN(String PAN) {
        this.PAN = PAN;
    }

    public String getTAN() {
        return TAN;
    }

    public void setTAN(String TAN) {
        this.TAN = TAN;
    }

    public int getTurnover() {
        return turnover;
    }

    public void setTurnover(int turnover) {
        this.turnover = turnover;
    }

    public int getExperienceOfInstitute() {
        return experienceOfInstitute;
    }

    public void setExperienceOfInstitute(int experienceOfInstitute) {
        this.experienceOfInstitute = experienceOfInstitute;
    }

    public String getNameOfCenter() {
        return nameOfCenter;
    }

    public void setNameOfCenter(String nameOfCenter) {
        this.nameOfCenter = nameOfCenter;
    }

    public int getOfficeManagerPhoneNumber() {
        return officeManagerPhoneNumber;
    }

    public void setOfficeManagerPhoneNumber(int officeManagerPhoneNumber) {
        this.officeManagerPhoneNumber = officeManagerPhoneNumber;
    }

    public int getOfficeStaffPhoneNumber() {
        return officeStaffPhoneNumber;
    }

    public void setOfficeStaffPhoneNumber(int officeStaffPhoneNumber) {
        this.officeStaffPhoneNumber = officeStaffPhoneNumber;
    }

    public int getLabAttendentsPhoneNumber() {
        return labAttendentsPhoneNumber;
    }

    public void setLabAttendentsPhoneNumber(int labAttendentsPhoneNumber) {
        this.labAttendentsPhoneNumber = labAttendentsPhoneNumber;
    }

    public int getAccountantPhoneNumber() {
        return accountantPhoneNumber;
    }

    public void setAccountantPhoneNumber(int accountantPhoneNumber) {
        this.accountantPhoneNumber = accountantPhoneNumber;
    }

    public int getSupportStaffPhoneNumber() {
        return supportStaffPhoneNumber;
    }

    public void setSupportStaffPhoneNumber(int supportStaffPhoneNumber) {
        this.supportStaffPhoneNumber = supportStaffPhoneNumber;
    }

    public int getOthersPhoneNumber() {
        return othersPhoneNumber;
    }

    public void setOthersPhoneNumber(int othersPhoneNumber) {
        this.othersPhoneNumber = othersPhoneNumber;
    }

    @Column(name="total_assessors")
    private int totalAssessors;

    public int getTotalAssessors() {
        return totalAssessors;
    }

    public void setTotalAssessors(int totalAssessors) {
        this.totalAssessors = totalAssessors;
    }
}
