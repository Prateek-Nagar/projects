package com.team4.scgj.Repository;

import com.team4.scgj.Entity.Application;
import com.team4.scgj.Entity.ManageRegSouvik;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ManageRegRepo extends CrudRepository<ManageRegSouvik,Long> {
    List<ManageRegSouvik> findAll();
}
