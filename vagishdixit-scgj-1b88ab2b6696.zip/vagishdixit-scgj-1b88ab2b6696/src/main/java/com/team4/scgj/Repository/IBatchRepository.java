
package com.team4.scgj.Repository;

import com.team4.scgj.Entity.Batch;
import com.team4.scgj.enums.BatchStatus;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface IBatchRepository extends CrudRepository<Batch, Integer> {


    @Query("SELECT SUM(u.totalCertified) from Batch u")
    int getTotalCertifed();

    @Query("Select sum(u.totalAppeared) from Batch u")
    int getTotalAssessed();

    @Query("SELECT SUM(u.totalCertified) from Batch u where u.batchMode =:mode")
    int getTotalCertifedMode(@Param("mode") String mode);

    @Query("Select sum(u.totalAppeared) from Batch u where u.batchMode =:mode")
    int getTotalAssessedMode(@Param("mode") String mode);

    @Query("select count(t) from TrainingCenter t")
    int getTainingCenterCount();

    @Query("select count(tp) from TrainingPartner tp")
    int getTrainingPartnerCount();

    @Query(" Select u.batchName from Batch u where u.assessorId is null")
    List<Batch> getNonAssignedBatch();

    @Query("select u.batchStatus from Batch u where u.batchId=:id")
    String batchName(@Param("id") int id);


    @Query("select b.batchName from Batch b")
    List<Integer> getAb();


    //    @Query("select count(u.batchId) as BatchNumber from Batch u where u.assessmentBodyId =:id ")
    @Query("select count(u.batchId)  from Batch u where u.assessmentBodyId.assessmentBodyId =:id ")
    int getElevenData(@Param("id") int id);

    List<Batch> findAllByBatchStatus(BatchStatus batchStatus);

}
