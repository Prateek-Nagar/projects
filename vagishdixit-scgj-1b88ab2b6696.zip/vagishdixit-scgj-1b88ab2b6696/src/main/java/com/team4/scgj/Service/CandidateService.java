package com.team4.scgj.Service;


import com.team4.scgj.Entity.Candidate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.PreparedStatement;
import java.util.List;

@Service
public class CandidateService {

    @Autowired
    JdbcTemplate jdbcTemplate;

//    public List<Candidate> getListCandidate(int id) {
//
//
//
//    }

}
