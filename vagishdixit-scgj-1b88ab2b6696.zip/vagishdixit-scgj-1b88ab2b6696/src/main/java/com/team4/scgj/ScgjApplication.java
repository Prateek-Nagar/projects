package com.team4.scgj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScgjApplication {

	public static void main(String[] args) {

		SpringApplication.run(ScgjApplication.class, args);
	}
}
