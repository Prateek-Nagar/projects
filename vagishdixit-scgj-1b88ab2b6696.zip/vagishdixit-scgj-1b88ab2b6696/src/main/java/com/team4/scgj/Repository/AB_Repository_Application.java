package com.team4.scgj.Repository;

import com.team4.scgj.Entity.Application;
import com.team4.scgj.Entity.AssessmentBody;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AB_Repository_Application extends CrudRepository<Application,Integer> {
    List<Application> findAll();
}
