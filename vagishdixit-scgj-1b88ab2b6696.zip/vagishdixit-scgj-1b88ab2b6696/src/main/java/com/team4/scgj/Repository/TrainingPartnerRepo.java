package com.team4.scgj.Repository;

import com.team4.scgj.Entity.TrainingPartner;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface TrainingPartnerRepo extends CrudRepository<TrainingPartner,Long> {
    List<TrainingPartner> findAll();
}
