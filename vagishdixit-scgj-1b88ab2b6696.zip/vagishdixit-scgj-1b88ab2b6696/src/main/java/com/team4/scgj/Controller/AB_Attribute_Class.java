package com.team4.scgj.Controller;

import java.util.Date;

public class AB_Attribute_Class {

    private int application_id;
    private String username;
    private String status;
    private String comments;
    private Date date;


    private int batchid;
    private Date assessmentDate;
    private String batchStrength;
    private String instructorname;


//    public AB_Attribute_Class(int application_id, String username, String status, String comments, Date date, Integer batchId, Date assessmentDate, String batchStrength, String instructorname ) {
//        this.application_id = application_id;
//        this.username = username;
//        this.status = status;
//        this.comments = comments;
//        this.date = date;
//        this.assessmentDate = assessmentDate;
//        this.batchStrength = batchStrength;
//        this.batchId = batchId;
//        this.instructorname=instructorname;
//    }

    public AB_Attribute_Class(int application_id, String username, String status, String comments, Date date) {
        this.application_id = application_id;
        this.username = username;
        this.status = status;
        this.comments = comments;
        this.date = date;
    }

//
//




    public Integer getBatchid() {
        return batchid;
    }

    public void setBatchid(Integer batchid) {
        this.batchid = batchid;
    }

    public Date getAssessmentDate() {
        return assessmentDate;
    }

    public void setAssessmentDate(Date assessmentDate) {
        this.assessmentDate = assessmentDate;
    }

    public String getBatchStrength() {
        return batchStrength;
    }

    public void setBatchStrength(String batchStrength) {
        this.batchStrength = batchStrength;
    }


//    public Integer getBatchId() {
//        return batchId;
//    }
//
//    public void setBatchId(Integer batchId) {
//        this.batchId = batchId;
//    }

    private int batchId;
    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }


    public int getApplication_id() {
        return application_id;
    }

    public void setApplication_id(int application_id) {
        this.application_id = application_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getInstructorname() {
        return instructorname;
    }

    public void setInstructorname(String instructorname) {
        this.instructorname = instructorname;
    }




}


