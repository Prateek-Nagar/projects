package com.team4.scgj.Services;

import com.team4.scgj.Entity.*;
import com.team4.scgj.Repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TP_Service {
    @Autowired
    TP_Repository_Application tp_repository_application;
    @Autowired
    Repository_User _repository_user;
    @Autowired
    TP_Repository_Batch tp_repository_batch;
    @Autowired
    TP_Repository_Trainer tp_repository_trainer;
    @Autowired
    TraningPartRepo traningPartRepo;
@Autowired
TP_Repository tp_repository;

    public List<User> findAlluser(){

        return _repository_user.findAll();
    }

    public List<Application> findAllappid(){

        return tp_repository_application.findAll();
    }

    public  List<TrainingPartner> findAllTP()
    {
    return traningPartRepo.findAll();
    }


    public List<Batch> findAllb(){

        return tp_repository_batch.findAll();
    }

    public List<Trainer> findAllt(){

        return tp_repository_trainer.findAll();
    }

//    public List<TrainingPartner> findAlltp(){
//        return tp_repository.findAll();
//    }


}
