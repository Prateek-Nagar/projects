package com.team4.scgj.Service;


import com.team4.scgj.Entity.Candidate;
import com.team4.scgj.Repository.ITCRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@Service
public class TCService {


    @Autowired
    ITCRepository itcRepository;

    @Autowired
    JdbcTemplate jdbcTemplate;

    public int getState(String name) {
        int stateCount = -1;

        String query = "select count(training_center_id) as countState from training_center,location where training_center.location_id = location.location_id and location.state = ?";
        try {
            PreparedStatement statement = jdbcTemplate.getDataSource().getConnection().prepareStatement(query);
            statement.setString(1, name);
            ResultSet count = statement.executeQuery();
            while (count.next()) {
                stateCount = count.getInt("countState");
            }

        } catch (Exception e) {

        }
        return stateCount;
    }


    public int getCountBatchAssessor() {

        int countBatch = 0;
        String query = "select count(batch_id) as batchCount from batch where batch.assessor_id is null";
        try {
            PreparedStatement statement = jdbcTemplate.getDataSource().getConnection().prepareStatement(query);
            ResultSet count = statement.executeQuery();
            while (count.next()) {
                countBatch = count.getInt("batchCount");
            }

        } catch (Exception e) {

        }
        return countBatch;
    }
}
