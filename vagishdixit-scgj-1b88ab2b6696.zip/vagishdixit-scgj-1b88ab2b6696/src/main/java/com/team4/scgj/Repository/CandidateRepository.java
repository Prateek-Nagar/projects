package com.team4.scgj.Repository;

import com.team4.scgj.Entity.Candidate;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface CandidateRepository extends CrudRepository<Candidate,Integer> {


//    List<Candidate> findByBatchId(int id);
}
