package com.team4.scgj.Entity;

import javax.persistence.*;

@Entity
@Table(name="managereg")
public class ManageRegSouvik {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    @Column(name="institutionName")
    private String institutionName;
    @Column(name="Type")
    private String institutionType;
    @Column(name="Date")
    private String Date;
    @Column(name="Location")
    private String location;
    @Column(name="comments",columnDefinition = "varchar(255) default 'no comments'")
    private String comments;
    @Column(name ="status",columnDefinition = "varchar(255) default 'Pending'")
    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getInstitutionName() {
        return institutionName;
    }

    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }

    public String getInstitutionType() {
        return institutionType;
    }

    public void setInstitutionType(String institutionType) {
        this.institutionType = institutionType;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public ManageRegSouvik() {
    }

    public ManageRegSouvik(String institutionName, String institutionType, String date, String location, String comments,String status) {

        this.institutionName = institutionName;
        this.institutionType = institutionType;
        Date = date;
        this.location = location;
        this.comments = comments;
        this.status=status;
    }
}
