package com.team4.scgj.Controller;

import java.util.Date;

public class AttributesClass {
    private int application_id;
    private String username;
    private String status;
    private String comments;



    //Batch mapping
    private int userId1;
    private int AppId1;
    private int TrainingPartnerId1;
    private int batchId1;
    private int instructorName1;
    private Date assessDate1;
    private String strength1;
    private String type1;
    private String status1;

    @Override
    public String toString() {
        return "AttributesClass{" +
                "application_id=" + application_id +
                ", username='" + username + '\'' +
                ", status='" + status + '\'' +
                ", comments='" + comments + '\'' +
                ", date=" + date +
                ", assessmentDate=" + assessmentDate +
                ", batchStrength='" + batchStrength + '\'' +
                ", instructorname='" + instructorname + '\'' +
                ", batchId=" + batchId +
                '}';
    }

    private Date date;

//    public int getTpid() {
//        return tpid;
//    }
//
//    public void setTpid(int tpid) {
//        this.tpid = tpid;
//    }
//
//    public int getApid() {
//        return apid;
//    }
//
//    public void setApid(int apid) {
//        this.apid = apid;
//    }
//
//    private int tpid;
//    private int apid;


    //private int batchid;
    private Date assessmentDate;
    private String batchStrength;
    private String instructorname;


    public AttributesClass(int application_id,Date date, String username, String status, String comments,  Integer batchId,  String instructorname, Date assessmentDate, String batchStrength) {
        this.application_id = application_id;
        this.username = username;
        this.status = status;
        this.comments = comments;
        this.date = date;
        this.assessmentDate = assessmentDate;
        this.batchStrength = batchStrength;
        this.batchId = batchId;
        this.instructorname=instructorname;
    }

    public AttributesClass() {
    }

    //    public Integer getBatchid() {
//        return batchid;
//    }
//
//    public void setBatchid(Integer batchid) {
//        this.batchid = batchid;
//    }

    public Date getAssessmentDate() {
        return assessmentDate;
    }

    public void setAssessmentDate(Date assessmentDate) {
        this.assessmentDate = assessmentDate;
    }

    public String getBatchStrength() {
        return batchStrength;
    }

    public void setBatchStrength(String batchStrength) {
        this.batchStrength = batchStrength;
    }


    public Integer getBatchId() {
        return batchId;
    }

    public void setBatchId(Integer batchId) {
        this.batchId = batchId;
    }

    private int batchId;
    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }


    public int getApplication_id() {
        return application_id;
    }

    public void setApplication_id(int application_id) {
        this.application_id = application_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getInstructorname() {
        return instructorname;
    }

    public void setInstructorname(String instructorname) {
        this.instructorname = instructorname;
    }




}
