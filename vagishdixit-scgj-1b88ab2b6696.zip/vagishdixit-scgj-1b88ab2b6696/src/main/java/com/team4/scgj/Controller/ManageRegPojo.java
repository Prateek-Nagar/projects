package com.team4.scgj.Controller;

public class ManageRegPojo {
    private Integer applicationId;
    private String institutionName;
    private String type;
    private String date;
    private String location;
    private String status;

    public String getStatus() {

        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getApplicationId() {
        return applicationId;
    }

    public ManageRegPojo() {
    }

    public ManageRegPojo(Integer applicationId, String institutionName, String type, String date, String location) {

        this.applicationId = applicationId;
        this.institutionName = institutionName;
        this.type = type;
        this.date = date;
        this.location = location;
    }

    public void setApplicationId(Integer applicationId) {
        this.applicationId = applicationId;
    }

    public String getInstitutionName() {
        return institutionName;
    }

    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
