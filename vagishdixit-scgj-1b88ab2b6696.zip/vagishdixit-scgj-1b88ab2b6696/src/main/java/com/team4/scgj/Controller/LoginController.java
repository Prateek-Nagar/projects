package com.team4.scgj.Controller;

import com.team4.scgj.Entity.User;
import com.team4.scgj.Service.LoginService;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Optional;

@Controller
//@SessionAttributes("userName")
@RequestMapping("/log")
public class LoginController {

    @Autowired
    LoginService loginService;

   /* @Value("${formSucess.message:Hello}")
    private String message;*/
    @RequestMapping(value = "/login", method = RequestMethod.GET)
    ModelAndView getLogin(HttpSession session) {
        Integer id=session.getAttribute("loggedInUser")!=null? Integer.valueOf(session.getAttribute("loggedInUser").toString()) :null;

        if(id==null)
        {
            ModelAndView modelAndView = new ModelAndView("login");
            modelAndView.addObject("login", new User());
            return modelAndView;
        }
            else {
            User user = loginService.find(id);
            if (user.getUserType().equals("Admin")) {
                return new ModelAndView("redirect:/scgj/dashboard");
            } else if (user.getUserType().equals("TP")) {
                return new ModelAndView("redirect:/tp/tpform");
            } else  {
                return new ModelAndView("redirect:/ab/abform");
            }



        }

    }


    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public ModelAndView formSucess(@ModelAttribute("login") User responseData, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("login");


        User loginStatus = loginService.validateUser(responseData);

        if (loginStatus != null) {
            session.setAttribute("loggedInUser", loginStatus.getUserId());
            if (loginStatus.getUserType().equals("Admin")) {
                return new ModelAndView("redirect:/scgj/dashboard");
            } else if (loginStatus.getUserType().equals("TP")) {
                return new ModelAndView("redirect:/tp/tpform");
            } else if (loginStatus.getUserType().equals("AB")) {
                return new ModelAndView("redirect:/ab/abform");
            }
        } else {

            ModelAndView modelAndView1=new ModelAndView("redirect:/log/login").addObject("error","Wrong Username Password");

            //return modelAndView.addObject("message",this.message);
           return new ModelAndView("login").addObject("error", "username or password Wrong");

        }
        return modelAndView;
    }





    @RequestMapping(value="/logout",method=RequestMethod.POST)
    public ModelAndView logout(HttpSession session)
    {
        session.removeAttribute("loggedInUser");
        return new ModelAndView("redirect:/log/login");
    }

}
