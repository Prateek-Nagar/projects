package com.team4.scgj.Repository;

import com.team4.scgj.Entity.Forms;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IFormsRepository extends CrudRepository<Forms, Integer> {

}
