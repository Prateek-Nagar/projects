package com.team4.scgj.Repository;

import com.team4.scgj.Entity.Application;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ApplicationRepo extends CrudRepository<Application,Long> {
    List<Application> findByStatus(String string);
}
