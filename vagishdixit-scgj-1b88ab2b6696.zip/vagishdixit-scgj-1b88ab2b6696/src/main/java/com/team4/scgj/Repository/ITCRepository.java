package com.team4.scgj.Repository;

import com.team4.scgj.Entity.TrainingCenter;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ITCRepository extends CrudRepository<TrainingCenter, Integer> {

//    @Query("select t.state,count(t.trainingCenterId) from TrainingCenter t group by t.state")
//    List<TrainingCenter> list();
//
//    @Query("select count(t.trainingCenterId) from TrainingCenter t")
//    int countByTrainingCenterID();


}
