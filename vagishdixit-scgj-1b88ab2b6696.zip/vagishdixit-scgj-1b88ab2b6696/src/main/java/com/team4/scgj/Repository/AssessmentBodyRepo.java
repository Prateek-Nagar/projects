package com.team4.scgj.Repository;

import com.team4.scgj.Entity.AssessmentBody;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface AssessmentBodyRepo extends CrudRepository<AssessmentBody,Long> {
    List<AssessmentBody> findAll();
}
