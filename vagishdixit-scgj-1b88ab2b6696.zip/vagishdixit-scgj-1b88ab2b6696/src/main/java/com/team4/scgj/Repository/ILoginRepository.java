package com.team4.scgj.Repository;

import com.team4.scgj.Entity.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ILoginRepository extends CrudRepository<User, Integer> {
   User findByUserNameAndUserPassword(String userName, String Password);

    User findByUserName(String userName);
    User findByUserId(int userId);
}
