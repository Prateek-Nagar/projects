package com.team4.scgj.Controller;

import java.util.Date;

public class BatchesMapping {
    private int userId1;
    private int AppId1;
    private int TrainingPartnerId1;
    private int batchId1;
    private int instructorName1;
    private Date assessDate1;
    private String strength1;
    private String type1;
    private String status1;
// default constructor


    public BatchesMapping() {
    }
    // parameterized constructor


    public BatchesMapping(int userId1, int appId1, int trainingPartnerId1, int batchId1, int instructorName1, Date assessDate1, String strength1, String type1, String status1) {
        this.userId1 = userId1;
        AppId1 = appId1;
        TrainingPartnerId1 = trainingPartnerId1;
        this.batchId1 = batchId1;
        this.instructorName1 = instructorName1;
        this.assessDate1 = assessDate1;
        this.strength1 = strength1;
        this.type1 = type1;
        this.status1 = status1;
    }
    // getter and setter

    public int getUserId1() {
        return userId1;
    }

    public void setUserId1(int userId1) {
        this.userId1 = userId1;
    }

    public int getAppId1() {
        return AppId1;
    }

    public void setAppId1(int appId1) {
        AppId1 = appId1;
    }

    public int getTrainingPartnerId1() {
        return TrainingPartnerId1;
    }

    public void setTrainingPartnerId1(int trainingPartnerId1) {
        TrainingPartnerId1 = trainingPartnerId1;
    }

    public int getBatchId1() {
        return batchId1;
    }

    public void setBatchId1(int batchId1) {
        this.batchId1 = batchId1;
    }

    public int getInstructorName1() {
        return instructorName1;
    }

    public void setInstructorName1(int instructorName1) {
        this.instructorName1 = instructorName1;
    }

    public Date getAssessDate1() {
        return assessDate1;
    }

    public void setAssessDate1(Date assessDate1) {
        this.assessDate1 = assessDate1;
    }

    public String getStrength1() {
        return strength1;
    }

    public void setStrength1(String strength1) {
        this.strength1 = strength1;
    }

    public String getType1() {
        return type1;
    }

    public void setType1(String type1) {
        this.type1 = type1;
    }

    public String getStatus1() {
        return status1;
    }

    public void setStatus1(String status1) {
        this.status1 = status1;
    }

    // toString


    @Override
    public String toString() {
        return "BatchesMapping{" +
                "userId1=" + userId1 +
                ", AppId1=" + AppId1 +
                ", TrainingPartnerId1=" + TrainingPartnerId1 +
                ", batchId1=" + batchId1 +
                ", instructorName1=" + instructorName1 +
                ", assessDate1=" + assessDate1 +
                ", strength1='" + strength1 + '\'' +
                ", type1='" + type1 + '\'' +
                ", status1='" + status1 + '\'' +
                '}';
    }
}
