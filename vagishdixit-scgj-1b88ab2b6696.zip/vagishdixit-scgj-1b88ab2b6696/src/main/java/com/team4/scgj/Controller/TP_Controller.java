package com.team4.scgj.Controller;

import com.team4.scgj.Entity.*;
import com.team4.scgj.Services.TP_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class TP_Controller {


    @Autowired
     TP_Service TP_service;

    int aid;
    String username=null;
    String status;
    Date date;
    String comments;
    int bid;
    Date assDate;
    String strength;
    String instructorname;



//    @RequestMapping(value="/get-userid", method=RequestMethod.POST) //OR @RequestMapping("get-string")
//    @ResponseBody

//    public User getString(@RequestParam int userid)
//    {
//        System.out.println("User id is" + userid);
//        User response = new User();
//        response.setUserId(userid);
//
//        List<Application> listapp= TP_service.findAllappid();
//
//        List<Batch> listbatch= TP_service.findAllb();
//        List<Trainer> listtrainer= TP_service.findAllt();
//        List<TrainingPartner> trainingPartnerList=TP_service.findAllTP() ;
//        ArrayList<AttributesClass> al=new ArrayList<>();
//
//        ArrayList<BatchesMapping> bm= new ArrayList<>();
//
//        List<User> listuser= TP_service.findAlluser();
//        for(Application a:listapp)
//        {
//            if(a.getUserId().getUserId().equals(userid)) {
//
//            //  if(a.getUserId().getUserId().equals(1)) {
//
//                aid = a.getApplicationId();
//                System.out.println(aid);
//
//                status = a.getStatus();
//                System.out.println(status);
//
//                date = a.getDate();
//                System.out.println(date);
//                comments = a.getComment();
//                for (User u : listuser) {
//                    if (a.getUserId().getUserId() == u.getUserId()) {
//                        //System.out.println("jgfkd");
//                        username = u.getUserName();
////                        uid=u.getUserId();
//                        //System.out.println(username);
//
//                    }
//                }
//            }
//        }
//
//
//
//
//        for(Batch b2: listbatch)
//
//        {
//
//            System.out.println("hello");
//// if(b2.getTrainingPartnerId().equals(TP_Service.findAllTP()))
// if(b2.getTrainingPartnerId().getApplication().getUserId().getUserId().equals(userid) && b2.getTrainingPartnerId().getApplication().getStatus().equals("approved") && b2.getTrainingPartnerId().getApplication().getUserId().getUserType().equals("Training Partner"))
//        {
//
////        for(TrainingPartner a: trainingPartnerList)
////        {
////            if(a.getApplication().getUserId().equals(userid))
////
////            {
////                for(Application appp: listapp)
////                {
////
////
////            System.out.println("For loop");
////            if(appp.getStatus().equals("Approved"))
//// {
//
//                System.out.println("Inside if loop");
//                bid = b2.getBatchId();
//                System.out.println("Batch id"+bid);
//
//                assDate= b2.getAssessmentDate();
//                System.out.println("Assign Date"+assDate);
//
//                strength= b2.getBatchStrength();
//                System.out.println("Strength"+ strength);
//
//                for (Trainer t : listtrainer) {
//                    if (b2.getTrainerId().getTrainerId() == t.getTrainerId()) {
//                        //System.out.println("jgfkd");
//                        instructorname = t.getTrainerName();
//                        System.out.println(instructorname);
//
//                    }
//                }
//            }
//        }
//
//          return response;
//
//    }

    @RequestMapping(value="/TPHomepage", method=RequestMethod.GET)
    @ResponseBody
    public ModelAndView TPHomepage(@RequestParam int userid)
    {
        System.out.println("User id is" + userid);
        User response = new User();
        response.setUserId(userid);

        List<Application> listapp= TP_service.findAllappid();

        List<Batch> listbatch= TP_service.findAllb();
        List<Trainer> listtrainer= TP_service.findAllt();
        List<TrainingPartner> trainingPartnerList=TP_service.findAllTP() ;
        ArrayList<AttributesClass> al=new ArrayList<>();

        ArrayList<BatchesMapping> bm= new ArrayList<>();

        List<User> listuser= TP_service.findAlluser();
        for(Application a:listapp)
        {
            AttributesClass attributesClass = new AttributesClass();
            if(a.getUserId().getUserId().equals(userid)) {
                attributesClass.setApplication_id(a.getApplicationId());
                attributesClass.setStatus(a.getStatus());
                attributesClass.setDate(a.getDate());
                attributesClass.setComments(a.getComment());
                attributesClass.setUsername(listuser.stream().filter(user -> user.getUserId() == a.getUserId().getUserId()).findFirst().orElse(new User()).getUserName());
                al.add(attributesClass);
            }
        }

        List<Batch> approvedBatch = listbatch.stream().filter(batch -> batch.getTrainingPartnerId().getApplication().getUserId().getUserId().equals(userid)
                && batch.getTrainingPartnerId().getApplication().getStatus().equals("approved")).collect(Collectors.toList());


        for(Batch b2: approvedBatch)
        {
            AttributesClass attributesClass = new AttributesClass();
                attributesClass.setBatchId(b2.getBatchId());
                attributesClass.setAssessmentDate(b2.getAssessmentDate());
                attributesClass.setBatchStrength(b2.getBatchStrength());
                for (Trainer t : listtrainer) {
                    if (b2.getTrainerId().getTrainerId() == t.getTrainerId()) {
                        attributesClass.setInstructorname(t.getTrainerName());
                    }
                }
                al.add(attributesClass);
        }

        ModelAndView model=new ModelAndView("TP-Copy");
                model.addObject("sakshi",al);
        return model;
    }
}
