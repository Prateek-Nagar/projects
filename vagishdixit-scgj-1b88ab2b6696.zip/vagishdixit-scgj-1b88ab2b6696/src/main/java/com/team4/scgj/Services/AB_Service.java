package com.team4.scgj.Services;

import com.team4.scgj.Entity.Application;
import com.team4.scgj.Entity.User;
import com.team4.scgj.Repository.AB_Repository_Application;
import com.team4.scgj.Repository.Repository_User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AB_Service {
    @Autowired
AB_Repository_Application ab_repository_application;
Repository_User repository_user;

    public List<Application> findAllABapp(){
        return ab_repository_application.findAll();
    }

    public List<User> findAlluser(){

        return repository_user.findAll();
    }
}
