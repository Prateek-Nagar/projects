package com.team4.scgj.Repository;

import com.team4.scgj.Entity.AssessmentBody;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface IABRepository extends CrudRepository<AssessmentBody , Integer> {

}
