package com.team4.scgj.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AbController {
    @RequestMapping("/getAbForm")
    public ModelAndView getAbForm()
    {
        ModelAndView modelAndView=new ModelAndView("ABForm");
        return modelAndView;
    }
}
