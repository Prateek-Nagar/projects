package com.team4.scgj.Controller;

import com.team4.scgj.Entity.ManageRegSouvik;
import com.team4.scgj.Service.ManageRegServiceSouvik;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import java.sql.PreparedStatement;
import java.util.List;

@RestController
public class ManageRegistrationController {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private ManageRegServiceSouvik manageRegServiceSouvik;
   /* @RequestMapping(value = "/manageReg", method = RequestMethod.GET)
    public ModelAndView messages1() {
        ModelAndView mav = new ModelAndView("ManageRegistration");
        mav.addObject("result1", manageRegServiceSouvik.findAllUserPending("Pending"));
        mav.addObject("result2", manageRegServiceSouvik.findAllUserPending("Approved"));
        mav.addObject("result3", manageRegServiceSouvik.findAllUserPending("Rejected"));
        mav.addObject("result4", manageRegServiceSouvik.findAllUserPending("Incomplete"));
        return mav;
    }*/

    @RequestMapping(value = "/manageReg", method = RequestMethod.GET)
    public ModelAndView messages1() {
        ModelAndView mav = new ModelAndView("ManageRegistration");
        mav.addObject("result1", manageRegServiceSouvik.getRegApplicationForm("Pending"));
        mav.addObject("result2", manageRegServiceSouvik.getRegApplicationForm("Approved"));
        mav.addObject("result3", manageRegServiceSouvik.getRegApplicationForm("Rejected"));
        mav.addObject("result4", manageRegServiceSouvik.getRegApplicationForm("Incomplete"));
        return mav;
    }




   /*
   @RequestMapping(value = "/manageReg", method = RequestMethod.GET)
    */
   /*
    public ModelAndView messages1() {
        ModelAndView mav = new ModelAndView("ManageRegistration");
       /* mav.addObject("result1", manageRegServiceSouvik.findAllUserPending("Pending"));
        mav.addObject("result2", manageRegServiceSouvik.findAllUserPending("Approved"));
        mav.addObject("result3", manageRegServiceSouvik.findAllUserPending("Rejected"));
        mav.addObject("result4", manageRegServiceSouvik.findAllUserPending("Incomplete"));*/
     /*  mav.addObject("result1",manageRegServiceSouvik.getRegApplicationForm());
        return mav;
    }*/










    /*@RequestMapping(value = "/manageReg1", method = RequestMethod.GET)
    public List<ManageRegSouvik> messages2() {
        ModelAndView mav1 = new ModelAndView("ManageRegistration");
        mav1.addObject("result2", manageRegServiceSouvik.findAllUserPending("Approved"));
        return manageRegServiceSouvik.findAllUserPending("Approved");
    }
    @RequestMapping(value = "/manageReg2", method = RequestMethod.GET)
    public ModelAndView messages3() {
        ModelAndView mav2 = new ModelAndView("ManageRegistration");
        mav2.addObject("result3", manageRegServiceSouvik.findAllUserPending("Rejected"));
        return mav2;
    }
    @RequestMapping(value = "/manageReg3", method = RequestMethod.GET)
    public ModelAndView messages4() {
        ModelAndView mav3 = new ModelAndView("ManageRegistration");
        mav3.addObject("result4", manageRegServiceSouvik.findAllUserPending("Incomplete"));
        return mav3;
    }*/
   /* @RequestMapping(value = "/insertStatus/{id}" ,method= RequestMethod.GET)
    public  ModelAndView afterInsert(@PathVariable String id)
    {
        int regId =Integer.parseInt(id);
        String query="UPDATE managereg SET  status= 'Approved' WHERE id = ?";
        try  {
            PreparedStatement statement = jdbcTemplate.getDataSource().getConnection().prepareStatement(query);
            statement.setInt(1,regId);
            statement.executeUpdate()   ;
        }
        catch (Exception e)
        {

        }
        ModelAndView modelAndView=new ModelAndView("ManageRegistration");
        return modelAndView;
    }*/
    @RequestMapping(value = "/insertStatus" ,method= RequestMethod.GET)
    public  ModelAndView afterInsertComment(@RequestParam String id,@RequestParam String comment)
    {
        System.out.println(id+" "+comment);
        int regId =Integer.parseInt(id);
        String query="UPDATE Application SET  status= 'Approved',comment= ? WHERE application_id = ?";
        try  {
            PreparedStatement statement = jdbcTemplate.getDataSource().getConnection().prepareStatement(query);
            statement.setString(1,comment);
            statement.setInt(2,regId);
            statement.executeUpdate()   ;
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        ModelAndView modelAndView=new ModelAndView("ManageRegistration");
        return modelAndView;
    }

    @RequestMapping(value = "/rejectStatus" ,method= RequestMethod.GET)
    public  ModelAndView afterReject(@RequestParam String id,@RequestParam String comment)
    {
        int regId =Integer.parseInt(id);
        String query="UPDATE Application SET  status= 'Rejected',comment=? WHERE application_id = ?";
        try  {
            PreparedStatement statement = jdbcTemplate.getDataSource().getConnection().prepareStatement(query);
            statement.setString(1,comment);
            statement.setInt(2,regId);
            statement.executeUpdate()   ;
        }
        catch (Exception e)
        {

        }
        ModelAndView modelAndView=new ModelAndView("ManageRegistration");
        return modelAndView;
    }
    @RequestMapping(value = "/incompleteStatus" ,method= RequestMethod.GET)
    public  ModelAndView afterIncompleteStatus(@RequestParam String id,@RequestParam String comment)
    {
        int regId =Integer.parseInt(id);
        String query="UPDATE application SET  status= 'Incomplete',comment=? WHERE application_id = ?";
        try  {
            PreparedStatement statement = jdbcTemplate.getDataSource().getConnection().prepareStatement(query);
            statement.setString(1,comment);
            statement.setInt(2,regId);
            statement.executeUpdate()   ;
        }
        catch (Exception e)
        {

        }
        ModelAndView modelAndView=new ModelAndView("ManageRegistration");
        return modelAndView;
    }

}
