package com.team4.scgj.Controller;

import com.team4.scgj.Entity.Forms;
import com.team4.scgj.Service.FormsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FormsController {


    @Autowired
    FormsService formsService;

    @RequestMapping(value = "/form")
    public ModelAndView getForm() {
        System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
        ModelAndView modelAndView = new ModelAndView("TPform");
        modelAndView.addObject("user", new Forms());
        return modelAndView;
    }

    @RequestMapping(value = "/form",method = RequestMethod.POST)
    public ModelAndView getAbcd(@ModelAttribute("user") Forms forms, BindingResult bindingResult)
    {
        if(bindingResult.hasErrors()){
            bindingResult.getAllErrors().forEach(System.out::println);
        }
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>");
        ModelAndView modelAndView = new ModelAndView("TPform");
        formsService.addData(forms);
        return modelAndView;
    }



}
