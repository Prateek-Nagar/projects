package com.team4.scgj.Service;

import com.team4.scgj.Entity.Forms;
import com.team4.scgj.Repository.IFormsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FormsService {
    @Autowired
    IFormsRepository iFormsRepository;
    public void addData(Forms forms) {

        iFormsRepository.save(forms);

    }
}
