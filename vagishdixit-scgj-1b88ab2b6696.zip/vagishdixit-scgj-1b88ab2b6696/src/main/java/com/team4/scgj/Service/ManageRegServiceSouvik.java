package com.team4.scgj.Service;

import com.team4.scgj.Controller.ManageRegPojo;
import com.team4.scgj.Entity.*;
import com.team4.scgj.Repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.util.ArrayList;
import java.util.List;

@Service
public class ManageRegServiceSouvik {
    @Autowired
    private ManageRegRepo manageRegRepo;
    @Autowired
    private ApplicationRepo applicationRepo;
    @Autowired
    private LocationRepo locationRepo;
    @Autowired
    private TrainingPartnerRepo trainingPartnerRepo;
    @Autowired
    private AssessmentBodyRepo assessmentBodyRepo;

    List<Application> listOfApplication=new ArrayList<>();
    List<Location> listOfLocation=new ArrayList<>();
    List<TrainingPartner> listOfTrainingPartner=new ArrayList<>();
    List<AssessmentBody> listOfAssessmentPartner=new ArrayList<>();
    List<ManageRegSouvik> listOfUsers = new ArrayList<>();
   /* public List<ManageRegSouvik> findAllUserPending(String string)
    {
        List<ManageRegSouvik> listOfUsers = new ArrayList<>();
        listOfUsers=manageRegRepo.findByStatus(string);
        return listOfUsers;
    }*/

    public List<Application> findAllApplication()
    {
        //List<Application> listOfApplication=new ArrayList<>();
        listOfApplication=applicationRepo.findByStatus("Pending");
        return listOfApplication;
    }
    public List<Location> findAllLocation()
    {

        listOfLocation=locationRepo.findAll();
        return listOfLocation;
    }
    public List<TrainingPartner> findAllTrainingPartner()
    {

        listOfTrainingPartner=trainingPartnerRepo.findAll();
        return listOfTrainingPartner;
    }
    public List<AssessmentBody> findAllAssessmentPartner()
    {

        listOfAssessmentPartner=assessmentBodyRepo.findAll();
        return listOfAssessmentPartner;
    }

   public  List<ManageRegPojo> getRegApplicationForm(String string)
    {
        List<ManageRegPojo> manageRegPojos=new ArrayList<>();
        for(Application application:applicationRepo.findByStatus(string))
        {
            for(TrainingPartner tp:trainingPartnerRepo.findAll())
            {
                if(application.getApplicationId().equals(tp.getApplication().getApplicationId()))
                {
                    for(Location location:locationRepo.findAll())
                    {
                        if(location.getLocationId().equals(tp.getLocation().getLocationId()))
                        {
                            ManageRegPojo m=new ManageRegPojo();
                           // m.setDate(application.getDate());
                            m.setLocation(location.getState());
                            m.setType("TP");
                            m.setInstitutionName(tp.getTrainingPartnerName());
                            m.setApplicationId(tp.getApplication().getApplicationId());
                            manageRegPojos.add(m);
                        }
                    }
                }
            }
            for(AssessmentBody ab:assessmentBodyRepo.findAll())
            {
                if(application.getApplicationId().equals(ab.getApplication().getApplicationId()))
                {
                    for(Location location:locationRepo.findAll())
                    {
                        if(location.getLocationId().equals(ab.getLocation().getLocationId()))
                        {
                            ManageRegPojo m=new ManageRegPojo();
                            m.setLocation(location.getState());
                            m.setType("AB");
                            m.setInstitutionName(ab.getAssessmentBodyName());
                            m.setApplicationId(ab.getApplication().getApplicationId());
                            manageRegPojos.add(m);
                        }
                    }
                }
            }
        }
        return manageRegPojos;

    }
    /*
    public List<ManageRegSouvik> findAllUserRejected()
    {
        List<ManageRegSouvik> listOfUsers = new ArrayList<>();
        listOfUsers=manageRegRepo.findByStatus("Rejected");
        return listOfUsers;
    }
    public List<ManageRegSouvik> findAllUserApproved()
    {
        List<ManageRegSouvik> listOfUsers = new ArrayList<>();
        listOfUsers=manageRegRepo.findByStatus("Approved");
        return listOfUsers;
    }
    public List<ManageRegSouvik> findAllUserIncomplete()
    {
        List<ManageRegSouvik> listOfUsers = new ArrayList<>();
        listOfUsers=manageRegRepo.findByStatus("Incomplete");
        return listOfUsers;
    }*/


}
