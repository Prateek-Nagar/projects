package com.team4.scgj.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class FaqController {
    @RequestMapping("getFaqPage")
    public ModelAndView getFaqPage()
    {
        ModelAndView modelAndView=new ModelAndView("FAQ");
        return modelAndView;
    }
}
