package com.team4.scgj.Controller;


import com.fasterxml.jackson.databind.util.JSONPObject;
import com.team4.scgj.Entity.Batch;
import com.team4.scgj.Entity.Candidate;
import com.team4.scgj.Entity.TrainingCenter;
import com.team4.scgj.Service.BatchService;
import com.team4.scgj.Service.CandidateService;
import com.team4.scgj.Service.TCService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

@Controller

public class FAQConroller {

    @Autowired
    BatchService batchService;

    @Autowired
    CandidateService candidateService;


    @Autowired
    TCService tcService;

    @RequestMapping("/getFirst")
    @ResponseBody
    public ModelAndView getFaq() {
        ModelAndView modelAndView = new ModelAndView("FAQ");

        return modelAndView;
    }

    //working
    @RequestMapping("/first/faq")
    @ResponseBody
    public ModelAndView getFirst() {
        ModelAndView modelAndView = new ModelAndView("FAQ");
        int result1 = batchService.getAssessed();
        int result2 = batchService.getCertified();
        modelAndView.addObject("result1", result1);
        modelAndView.addObject("result2", result2);
        return modelAndView;
    }

    //working
    @RequestMapping("/second/faq/{batchMode}")
    @ResponseBody
    public ModelAndView getSecond(@PathVariable String batchMode) {
        ModelAndView modelAndView = new ModelAndView("FAQ");
        modelAndView.addObject("result1", batchService.getCertifiedMode(batchMode));
        modelAndView.addObject("result2", batchService.getAssessedMode(batchMode));
        return modelAndView;

    }

    @RequestMapping("/third/faq/{year}")
    @ResponseBody
    public ModelAndView getThird(String year) {
        ModelAndView modelAndView = new ModelAndView("FAQ");
        return modelAndView;

    }

    //working
    @RequestMapping("/eleven/faq/{id}")
    @ResponseBody
    public ModelAndView getEleven(@PathVariable int id) {
        ModelAndView modelAndView = new ModelAndView("FAQ");

        int batchList = batchService.getElevenData(id);

        modelAndView.addObject("eleven", "Number of batchs  " + batchList);


        return modelAndView;
    }


//    @RequestMapping("/nine/faq")
//    @ResponseBody
//    public ModelAndView getNine() {
//        ModelAndView modelAndView = new ModelAndView("FAQ");
//        modelAndView.addObject("item", "Number of training center we have currentl :  " + tcService.getTrainingCenter());
//        return modelAndView;
//    }

    //working
    @RequestMapping("/six/faq/{id)")
    @ResponseBody
    public ModelAndView getSix(@PathVariable int id) {
        ModelAndView modelAndView = new ModelAndView("FAQ");
        modelAndView.addObject("item6", batchService.getStatus(id));
        return modelAndView;
    }

//    @RequestMapping("/ten/faq/{id}")
//    public ModelAndView abc(@PathVariable int id) {
//        ModelAndView modelAndView = new ModelAndView("FAQ");
//        modelAndView.addObject("vagish", batchService.getABC(id));
//        return modelAndView;
//    }

//    @RequestMapping("/twelve/faq/{id}")
//    public String getTwelve(@PathVariable int id) {
//        ModelAndView modelAndView = new ModelAndView("FAQ");
//        String agencyName = batchService.getAgencyName(id);
////        modelAndView.addObject("twelve", agencyName);
//        return agencyName;
//    }

//    @RequestMapping("/get/Candidate/batch/{id}")
//    @ResponseBody
//    public List<Candidate> getCandidates(@PathVariable int id) {
//        List<Candidate> candidates = candidateService.getListCandidate();
//        return candidates;
//    }

    @RequestMapping("/state/{name}")
    @ResponseBody
    int stateCount(@PathVariable String name) {
        return tcService.getState(name);

    }

    //working
    @RequestMapping("/batch/assessor")
    @ResponseBody
    int countBatch() {
        return tcService.getCountBatchAssessor();
    }

    @RequestMapping("/batch/agency/{id}")
    @ResponseBody
    String agencyName(@PathVariable int id) {
        return batchService.getAgencyName(id);
    }

    @RequestMapping("/get/batch/candidate")
    @ResponseBody
    Map<Integer, Integer> getInt() {
        return batchService.getBatchCandidateCount();
    }


}
