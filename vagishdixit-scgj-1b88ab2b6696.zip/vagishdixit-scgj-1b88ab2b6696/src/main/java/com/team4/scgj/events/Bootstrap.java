package com.team4.scgj.events;

import com.team4.scgj.Entity.Batch;
import com.team4.scgj.Repository.IBatchRepository;
import com.team4.scgj.enums.BatchStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class Bootstrap {

    @Autowired
    IBatchRepository iBatchRepository;


    @EventListener(ContextRefreshedEvent.class)
    public void init(){
        System.out.println(".....................Starting up the application...............");
        System.out.println(iBatchRepository.findAll().iterator().hasNext());





    }
}
