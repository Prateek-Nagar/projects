package com.team4.scgj.Entity;


import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "application")
public class Application {


    public Application(){

    }


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer applicationId;

    @Column(name="date")
    private Date date;

    @Column(name ="status")
    private String status="Pending";

    @Column(name = "comment")
    private String comment;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User userId;

    public Application(Date date, String status, String comment, User userId) {
        this.date = date;
        this.status = status;
        this.comment = comment;
        this.userId = userId;
    }


    public Date getDate() {
        return date;
    }


    public void setDate(Date date) {
        this.date = date;
    }


    public String getStatus() {
        return status;

    }

    public void setStatus(String status) {
        this.status = status;
    }


    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }


    public Integer getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(int applicationId) {
        this.applicationId = applicationId;
    }

    public User getUserId() {
        return userId;
    }

    public void setUserId(User userId) {
        this.userId = userId;
    }
}
