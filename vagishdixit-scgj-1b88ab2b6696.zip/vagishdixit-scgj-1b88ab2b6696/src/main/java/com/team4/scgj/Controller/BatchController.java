
package com.team4.scgj.Controller;

import com.team4.scgj.Entity.Batch;
import com.team4.scgj.Service.BatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

import com.team4.scgj.Entity.Batch;
import com.team4.scgj.Service.BatchService;
import com.team4.scgj.enums.BatchStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.sql.PreparedStatement;
import java.util.List;

@Controller
public class BatchController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private BatchService batchService;



    @RequestMapping(value = "/getBatch", method = RequestMethod.GET)
    public ModelAndView getBatch() {
        ModelAndView mav = new ModelAndView("batch");
        List<Batch> list = batchService.getBatchList(BatchStatus.PENDING);
        mav.addObject("result1",list);
        System.out.println(list);

        mav.addObject("result2", batchService.getBatchList(BatchStatus.PROPOSED));
       mav.addObject("result3", batchService.getBatchList(BatchStatus.APPROVED));
        mav.addObject("result4", batchService.getBatchList(BatchStatus.REJECTED));


        return mav;
    }

    @GetMapping("/saveBatch")
    @ResponseBody
    public String saveBatch(){
        batchService.saveBatchAndAssessmentBody();
        return "Success";
    }

    @RequestMapping(value = "/approvingStatus/{id}" ,method= RequestMethod.GET)
    public  ModelAndView afterInsert(@PathVariable String id)
    {
        int regId =Integer.parseInt(id);
        String query = "UPDATE batch SET  batch_status= 'PROPOSED' WHERE id = ?" ;
        try  {
            PreparedStatement statement = jdbcTemplate.getDataSource().getConnection().prepareStatement(query);
            statement.setInt(1,regId);
            statement.executeUpdate()   ;
        }
        catch (Exception e)
        {

        }
        ModelAndView modelAndView=new ModelAndView("batch");
        return modelAndView;
    }
    @RequestMapping(value = "/rejectingStatus/{id}" ,method= RequestMethod.GET)
    public  ModelAndView afterIncompleteStatus(@PathVariable String id)
    {
        int regId =Integer.parseInt(id);
        String query="UPDATE batch SET  batch_status= 'PENDING' WHERE id = ?";
        try  {
            PreparedStatement statement = jdbcTemplate.getDataSource().getConnection().prepareStatement(query);
            statement.setInt(1,regId);
            statement.executeUpdate()   ;
        }
        catch (Exception e)
        {

        }
        ModelAndView modelAndView=new ModelAndView("batch");
        return modelAndView;
    }

}

