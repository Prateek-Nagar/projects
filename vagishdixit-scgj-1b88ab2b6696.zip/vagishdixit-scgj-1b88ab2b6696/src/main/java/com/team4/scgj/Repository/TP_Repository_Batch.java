package com.team4.scgj.Repository;

import com.team4.scgj.Entity.Batch;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TP_Repository_Batch extends CrudRepository<Batch,Integer> {

    List<Batch>findAll();
}
