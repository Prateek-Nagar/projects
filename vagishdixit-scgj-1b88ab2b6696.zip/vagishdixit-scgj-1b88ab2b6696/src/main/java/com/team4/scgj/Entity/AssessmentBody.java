package com.team4.scgj.Entity;


import javax.persistence.*;

@Entity
@Table(name = "assessment_body")
public class AssessmentBody {

    @Id
    @Column(name = "assessment_id")
    private int assessmentBodyId;

    @Column(name = "assessment_body_name")
    private String assessmentBodyName;


    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "application_id")
    private Application application;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="location_id")
    private Location location;

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }



    public int getAssessmentBodyId() {
        return assessmentBodyId;
    }

    public void setAssessmentBodyId(int assessmentBodyId) {
        this.assessmentBodyId = assessmentBodyId;
    }

    public String getAssessmentBodyName() {
        return assessmentBodyName;
    }

    public void setAssessmentBodyName(String assessmentBodyName) {
        this.assessmentBodyName = assessmentBodyName;
    }

    public Application getApplication() {
        return application;
    }

    public void setApplicationId(Application application) {
        this.application = application;
    }
}
