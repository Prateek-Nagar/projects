package com.team4.scgj.Service;

import com.team4.scgj.Entity.Application;
import com.team4.scgj.Entity.User;
import com.team4.scgj.Repository.ILoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LoginService {

    @Autowired
    ILoginRepository iLoginRepository;
/*@Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;*/

    public User validateUser(User responseData) {

      User loginStatus = iLoginRepository.findByUserNameAndUserPassword(responseData.getUserName(), responseData.getUserPassword());
     /*   if(loginStatus!=null)
        {
            if(bCryptPasswordEncoder.matches(responseData.getUserPassword(),loginStatus.getUserPassword()))
            {
                return loginStatus;
            }
        }*/
     return loginStatus;

    }
    public User find(int userId)
    {
        User id=iLoginRepository.findByUserId(userId);
        return id;
    }


//    public boolean getFormStatus(String userName) {
//       User user = iLoginRepository.findByUserName(userName);
//        Application application = new Application(user.getUserId());
//        return application.isFormStatus();
//
//    }

}
