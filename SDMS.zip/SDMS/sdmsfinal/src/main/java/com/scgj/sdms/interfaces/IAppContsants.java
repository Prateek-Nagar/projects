package com.scgj.sdms.interfaces;

public interface IAppContsants {
   String UPLOADFOLDER="C:\\New folder\\sdms\\sdms\\src\\main\\resources\\Upload";
}
