package com.scgj.sdms.model;

public class MapToChartReadyData {
}
