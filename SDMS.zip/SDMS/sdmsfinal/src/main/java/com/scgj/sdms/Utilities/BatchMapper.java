package com.scgj.sdms.Utilities;

public class BatchMapper {
}
