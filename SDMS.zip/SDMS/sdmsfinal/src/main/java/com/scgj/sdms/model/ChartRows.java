package com.scgj.sdms.model;

import org.apache.commons.collections.map.MultiKeyMap;

import java.util.HashMap;

public class ChartRows {
    //MultiMap<String,ArrayList<MultiMap<String,String >>> row;
}
