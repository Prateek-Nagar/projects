package zenith.pet.project.petclinic.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import zenith.pet.project.petclinic.Repository.PetRepository;

@Service
public class PetService {

    @Autowired
    PetRepository petRepository;
}
