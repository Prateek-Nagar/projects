package zenith.pet.project.petclinic.Models;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;

@ToString
@Setter
@Getter
@NoArgsConstructor
@Entity
public class PetType extends BaseEntity {

    private String petName;

}
