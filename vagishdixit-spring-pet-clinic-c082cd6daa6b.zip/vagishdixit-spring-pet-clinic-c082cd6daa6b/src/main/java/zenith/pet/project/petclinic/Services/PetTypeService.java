package zenith.pet.project.petclinic.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import zenith.pet.project.petclinic.Repository.PetTypeRepository;

@Service
public class PetTypeService {

    @Autowired
    PetTypeRepository petTypeRepository;

}
