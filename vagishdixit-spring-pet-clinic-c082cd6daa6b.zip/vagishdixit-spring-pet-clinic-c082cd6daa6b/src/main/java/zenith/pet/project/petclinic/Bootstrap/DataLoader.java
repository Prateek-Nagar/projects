package zenith.pet.project.petclinic.Bootstrap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;
import zenith.pet.project.petclinic.Models.*;
import zenith.pet.project.petclinic.Repository.OwnerRepository;
import zenith.pet.project.petclinic.Repository.PetTypeRepository;
import zenith.pet.project.petclinic.Repository.SpecialityRepository;
import zenith.pet.project.petclinic.Repository.VetRepository;

import java.time.LocalDate;

@Component
public class DataLoader implements ApplicationListener<ContextRefreshedEvent> {

    @Autowired
    OwnerRepository ownerRepository;
    @Autowired
    VetRepository vetRepository;
    @Autowired
    PetTypeRepository petTypeRepository;
    @Autowired
    SpecialityRepository specialityRepository;


    private void startData() {



        PetType dog = new PetType();
        dog.setId(1L);
        dog.setPetName("Dog");
        petTypeRepository.save(dog);

        PetType cat = new PetType();
        cat.setId(2L);
        cat.setPetName("Cat");
        petTypeRepository.save(cat);

        Speciality radioLogist = new Speciality();
        radioLogist.setId(1L);
        radioLogist.setDescription("RadioLogist");
        specialityRepository.save(radioLogist);

        Speciality dentistry = new Speciality();
        dentistry.setId(2L);
        dentistry.setDescription("Dentistry");
        specialityRepository.save(dentistry);

        Owner owner1 = new Owner();
        owner1.setId(1L);
        owner1.setFirstName("Vagish");
        owner1.setLastName("Dixit");
        owner1.setOwnerAddress("Rajouri Garden");
        owner1.setOwnerCity("New Delhi");
        owner1.setOwnerTelephone("9716966334");

        Pet pet1 = new Pet();
        pet1.setId(1L);
        pet1.setOwner(owner1);
        pet1.setDateOfBirth(LocalDate.now());
        pet1.setPetType(dog);

        owner1.getPets().add(pet1);
        ownerRepository.save(owner1);

        Owner owner2 = new Owner();
        owner2.setId(2L);
        owner2.setFirstName("Maanvi");
        owner2.setLastName("Dixit");
        owner2.setOwnerTelephone("9650505175");
        owner2.setOwnerCity("Mumbai");
        owner2.setOwnerAddress("Malad");

        Pet pet2 = new Pet();
        pet2.setId(2L);
        pet2.setOwner(owner2);
        pet2.setDateOfBirth(LocalDate.now());
        pet2.setPetType(cat);

        owner2.getPets().add(pet2);
        ownerRepository.save(owner2);


        Vet vet1 = new Vet();
        vet1.setId(1L);
        vet1.setFirstName("ABCD");
        vet1.setLastName("Jonas");
        vet1.getSpecialities().add(radioLogist);
        vetRepository.save(vet1);

        Vet vet2 = new Vet();
        vet2.setId(2L);
        vet2.setFirstName("Joe");
        vet2.setLastName("Kallu");
        vet2.getSpecialities().add(dentistry);
        vetRepository.save(vet2);
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        startData();
    }
}
