package zenith.pet.project.petclinic.Models;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.MappedSuperclass;

@ToString
@Setter
@Getter
@NoArgsConstructor
@MappedSuperclass
public class Person extends BaseEntity{


    private String firstName;
    private String lastName;

}
