package zenith.pet.project.petclinic.Controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class OwnerController {

    @RequestMapping({"/owner","/owner/index","/owner/index.html"})
    private String getIndex()
    {
        return "owner/index";
    }

}
