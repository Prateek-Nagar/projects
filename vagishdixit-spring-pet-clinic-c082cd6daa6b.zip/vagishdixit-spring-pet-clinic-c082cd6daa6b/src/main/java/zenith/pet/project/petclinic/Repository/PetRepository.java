package zenith.pet.project.petclinic.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import zenith.pet.project.petclinic.Models.Pet;

@Repository
public interface PetRepository extends CrudRepository<Pet,Long> {
}
