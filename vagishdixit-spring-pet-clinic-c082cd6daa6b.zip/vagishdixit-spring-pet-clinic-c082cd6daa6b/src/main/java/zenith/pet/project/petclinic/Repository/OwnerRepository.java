package zenith.pet.project.petclinic.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import zenith.pet.project.petclinic.Models.Owner;

@Repository
public interface OwnerRepository extends CrudRepository<Owner,Long> {
}
