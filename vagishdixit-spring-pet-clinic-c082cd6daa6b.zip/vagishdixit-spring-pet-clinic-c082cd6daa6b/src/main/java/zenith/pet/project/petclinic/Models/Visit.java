package zenith.pet.project.petclinic.Models;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.time.LocalDate;

@ToString
@Setter
@Getter
@NoArgsConstructor
@Entity
public class Visit extends BaseEntity {

    private LocalDate visitData;

    private String description;

    @ManyToOne
    @JoinColumn(name = "pet_id")
    private Pet pet;

}
