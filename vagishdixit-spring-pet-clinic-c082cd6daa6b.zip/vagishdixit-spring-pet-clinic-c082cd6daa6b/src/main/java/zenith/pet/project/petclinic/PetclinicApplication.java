package zenith.pet.project.petclinic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"zenith.pet.project.petclinic.Controllers", "zenith.pet.project.petclinic.Services" , "zenith.pet.project.petclinic.Models"
,"zenith.pet.project.petclinic.Bootstrap","zenith.pet.project.petclinic.Repository"})
public class PetclinicApplication {

    public static void main(String[] args) {
        SpringApplication.run(PetclinicApplication.class, args);
    }
}
