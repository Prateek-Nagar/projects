package com.matrixdev.fingerprint;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.matrixdev.fingerprint.Helpers.DialogHelper;

public class BaseActivity extends AppCompatActivity {

    private AlertDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base);
    }

    public void startLoader() {
        if (dialog != null && !dialog.isShowing())
            dialog = DialogHelper.with(this).startIndicator();
        else if (dialog == null)
            dialog = DialogHelper.with(this).startIndicator();
    }

    public void stopLoader() {
        DialogHelper.with(this).stopIndicator(dialog);
    }


}
