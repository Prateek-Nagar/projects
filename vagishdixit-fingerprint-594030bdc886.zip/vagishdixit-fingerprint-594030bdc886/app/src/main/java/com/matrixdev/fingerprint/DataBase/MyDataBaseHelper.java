package com.matrixdev.fingerprint.DataBase;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDataBaseHelper extends SQLiteOpenHelper {

    public static SQLiteDatabase database;

    public MyDataBaseHelper(Context context) {
        super(context, "fingerprint", null, 3, new DatabaseErrorHandler() {
            @Override
            public void onCorruption(SQLiteDatabase sqLiteDatabase) {

            }
        });
        database = getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createStudent = "CREATE TABLE `student` (\n" +
                "\t`id`\tINTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\t`student_name`\tTEXT NOT NULL,\n" +
                "\t`fingerprint_id`\tINTEGER UNIQUE\n" +
                ");\n";


        db.execSQL(createStudent);


        String createAttandance = "CREATE TABLE `attendance` (\n" +
                "\t`id`\tINTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\t`day`\tTEXT,\n" +
                "\t`month`\tTEXT,\n" +
                "\t`year`\tTEXT,\n" +
                "\t`student_id`\tINTEGER NOT NULL,\n" +
                "\tFOREIGN KEY(`student_id`) REFERENCES `student`(`id`)\n" +
                ");";

        db.execSQL(createAttandance);

    }

    public void reload() {
        if (database != null) {
            database.close();
            database = getWritableDatabase();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
