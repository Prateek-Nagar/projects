package com.matrixdev.fingerprint.Model;

import android.database.Cursor;

import com.matrixdev.fingerprint.DataBase.MyDataBaseHelper;
import com.matrixdev.fingerprint.FingerPrintApplication;

import java.util.ArrayList;

public class StudentModel {

    int studentId;

    String studentName;

    int fingerPrintId;

    private ArrayList<StudentModel> studentList;

    public StudentModel(Cursor obj) {
        this.studentId = obj.getInt(0);
        this.studentName = obj.getString(1);
        this.fingerPrintId = obj.getInt(2);
    }

    public StudentModel() {

    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public int getFingerPrintId() {
        return fingerPrintId;
    }

    public void setFingerPrintId(int fingerPrintId) {
        this.fingerPrintId = fingerPrintId;
    }

    public StudentModel(int studentId, String studentName, int fingerPrintId) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.fingerPrintId = fingerPrintId;
    }

    public static ArrayList<StudentModel> loadAllStudent() {
        MyDataBaseHelper db = new MyDataBaseHelper(FingerPrintApplication.getContext());
        Cursor obj = db.database.rawQuery("Select * from student ", null);
        ArrayList<StudentModel> studentList = new ArrayList<>();
        while (obj.moveToNext()) {
            StudentModel studentModel = new StudentModel(obj);
            studentList.add(studentModel);
        }
        obj.close();
        return studentList;
    }


    public void addStudent() {
        MyDataBaseHelper db = new MyDataBaseHelper(FingerPrintApplication.getContext());
        String query = String.format("insert into student(id,student_name,fingerprint_id) values(null,'%s',null);", studentName);
        db.database.execSQL(query);
    }

    public boolean deleteStudent() {
        MyDataBaseHelper db = new MyDataBaseHelper(FingerPrintApplication.getContext());
        db.database.execSQL("delete from student where id=?", new String[]{String.valueOf(studentId)});
        return true;
    }


    public void save() {
        MyDataBaseHelper db = new MyDataBaseHelper(FingerPrintApplication.getContext());
        db.database.execSQL("update student set student_name=?,fingerprint_id=? where id=?", new String[]{studentName, String.valueOf(fingerPrintId), String.valueOf(studentId)});
    }
}
