package com.matrixdev.fingerprint;

import android.bluetooth.BluetoothDevice;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class DeviceAdapter extends RecyclerView.Adapter<DeviceAdapter.VH>{
    ArrayList<BluetoothDevice> devices;
    int selection[];
    BluetoothDevice selectedDevice;

    public DeviceAdapter(ArrayList<BluetoothDevice> devices) {
        this.devices = devices;
        selection= new int[devices.size()];
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View rootView = LayoutInflater.from(parent.getContext()).inflate(R.layout.simple_list_item, parent, false);;
        return new VH(rootView);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        holder.setup(devices.get(position),position);
    }

    @Override
    public int getItemCount() {
        return devices.size();
    }

    public BluetoothDevice getSelectedDevice() {
        return selectedDevice;
    }

    public class VH extends RecyclerView.ViewHolder {
        View view;
        public VH(@NonNull View itemView) {
            super(itemView);
            view = itemView;
        }

        public void setup(final BluetoothDevice bluetoothDevice, final int position) {
            ((TextView) view).setText(bluetoothDevice.getName());
            if(selection[position]==1)
                view.setBackgroundResource(R.color.colorPrimaryLight);
            else
                view.setBackgroundColor(Color.WHITE);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    selection = new int[devices.size()];
                    selection[position] = 1;
                    selectedDevice = bluetoothDevice;
                    notifyDataSetChanged();
                }
            });
        }
    }
}
