package com.matrixdev.fingerprint.Model;

import android.database.Cursor;

import com.matrixdev.fingerprint.DataBase.MyDataBaseHelper;
import com.matrixdev.fingerprint.FingerPrintApplication;

import java.util.ArrayList;
import java.util.Locale;

public class AttendanceModel {

    int attendanceId;

    String day;

    String month;

    String year;

    int studentId;

    private ArrayList<AttendanceModel> attendanceList;

    public AttendanceModel(Cursor obj) {
        this.attendanceId = obj.getInt(0);
        this.day = obj.getString(1);
        this.year = obj.getString(2);
        this.month = obj.getString(3);
        this.studentId = obj.getInt(4);
    }

    public int getAttendanceId() {
        return attendanceId;
    }

    public void setAttendanceId(int attendanceId) {
        this.attendanceId = attendanceId;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public AttendanceModel(String day, String month, String year, int studentId) {
        this.day = day;
        this.month = month;
        this.year = year;
        this.studentId = studentId;
    }

    public AttendanceModel(int day, int month, int year, int studentId) {
        this.day = "" + day;
        this.month = "" + month;
        this.year = "" + year;
        this.studentId = studentId;
    }

    public static ArrayList<AttendanceModel> loadAttendance() {
        MyDataBaseHelper db = new MyDataBaseHelper(FingerPrintApplication.getContext());
        Cursor obj = db.database.rawQuery("Select * from attendance ", null);
        ArrayList<AttendanceModel> attendanceList = new ArrayList<>();
        while (obj.moveToNext()) {
            AttendanceModel attendanceModel = new AttendanceModel(obj);
            attendanceList.add(attendanceModel);
        }
        obj.close();
        return attendanceList;
    }

    public void addAttendance(String day, String month, String year, int studentId) {
        MyDataBaseHelper db = new MyDataBaseHelper(FingerPrintApplication.getContext());
        String query = String.format(Locale.ENGLISH, "insert into attendance(attendanceId,day,month,year,studentId) values(null,'%s','%s','%s','%d');", day, month, year, studentId);
        db.database.execSQL(query);
    }

    public boolean removeAttendance() {
        MyDataBaseHelper db = new MyDataBaseHelper(FingerPrintApplication.getContext());
        db.database.execSQL("delete from attendance where id=?", new String[]{String.valueOf(attendanceId)});
        return true;
    }


    public void update() {
        MyDataBaseHelper db = new MyDataBaseHelper(FingerPrintApplication.getContext());
        db.database.execSQL("update attendance set student_id=?,day=?,month=?,year=? where id=?", new String[]{String.valueOf(studentId), day, month, year, String.valueOf(attendanceId)});
    }

    public void save() {
        MyDataBaseHelper db = new MyDataBaseHelper(FingerPrintApplication.getContext());
        db.database.execSQL("insert into attendance(student_id,day,month,year) values (?,?,?,?) ", new String[]{String.valueOf(studentId), day, month, year});
    }

    public static boolean findAttendance(String studentId, String day, String month, String year) {
        if (studentId == null)
            return false;
        MyDataBaseHelper db = new MyDataBaseHelper(FingerPrintApplication.getContext());
        String query = "Select * from attendance";
        query += String.format(" where student_id = %s and ", studentId);
        if (day != null)
            query += String.format("day = %s and ", day);
        if (month != null)
            query += String.format("month = %s and ", month);
        if (year != null)
            query += String.format("year = %s and ", year);

        query = query.substring(0, query.lastIndexOf("and"));
        Cursor res = db.database.rawQuery(query, null);
        if (res.getCount() == 0) {
            res.close();
            db.database.close();
            return false;
        } else {
            res.close();
            db.database.close();
            return true;
        }
    }
}
