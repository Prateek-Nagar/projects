package com.matrixdev.fingerprint;

import android.app.DatePickerDialog;
import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.matrixdev.fingerprint.DataBase.MyDataBaseHelper;
import com.matrixdev.fingerprint.Helpers.BluetoothHelper;
import com.matrixdev.fingerprint.Helpers.DialogHelper;
import com.matrixdev.fingerprint.Model.AttendanceModel;
import com.matrixdev.fingerprint.Model.Packet;
import com.matrixdev.fingerprint.Model.StudentModel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

import co.ceryle.radiorealbutton.BackgroundView;
import co.ceryle.radiorealbutton.RadioRealButton;
import co.ceryle.radiorealbutton.RadioRealButtonGroup;

public class MainActivity extends BaseActivity {
    private enum VisibleMode {MONTHLY, WEEKLY, CUSTOM}

    private VisibleMode visibleMode = VisibleMode.MONTHLY;

    private boolean editMode = false;
    private HorizontalScrollView scroll1;
    private HorizontalScrollView scroll2;
    private boolean scroll2Toched = false;
    private boolean scroll1Toched = false;
    private Toolbar myToolbar;
    private ImageView connectionButton;
    private BluetoothHelper bluetoothHelper;
    private TableRow tableHeader;

    private FloatingActionButton addStudent;
    private FloatingActionButton saveAttendace;
    private EditText studentName;
    private TableLayout studentPane;
    private ImageView refreshButton;
    private TableLayout attendancePane;
    private AlertDialog currentStudentDialog;
    private View calenderButton;

    private Calendar visibleStart;
    private Calendar visibleEnd;
    private int todayColumnIndex;
    private AlertDialog addStudentDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initUI();
        setListeners();
    }

    private void setListeners() {
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refresh();
            }
        });
        saveAttendace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (todayColumnIndex == -1)
                    return;
                ArrayList<StudentModel> students = StudentModel.loadAllStudent();
                StudentModel student;
                int pos = 0;
                for (int i = 0; i < students.size(); i++) {
                    student = students.get(i);
                    TableRow row = (TableRow) attendancePane.getChildAt(i);
                    View cell = row.getChildAt(todayColumnIndex);
                    CheckBox checkBox = cell.findViewById(R.id.cell_checkbox);
                    if(checkBox.isChecked())
                    {
                        Calendar today = Calendar.getInstance();
                        AttendanceModel attendance =  new AttendanceModel(today.get(Calendar.DAY_OF_MONTH),today.get(Calendar.MONTH),today.get(Calendar.YEAR),student.getStudentId());
                        attendance.save();
                    }
                }
            }
        });
        calenderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogHelper.with(MainActivity.this).showCustomDialog(R.layout.calendar_mode, new DialogHelper.ViewHandler() {
                    public View rangeLayout;
                    public TextView endDateText;
                    public TextView startDateText;
                    public View endDateButton;
                    public View startDateButton;
                    public RadioRealButtonGroup group;
                    public View closeButton;
                    SimpleDateFormat format;

                    @Override
                    public void init(AlertDialog dialog) {
                        closeButton = dialog.findViewById(R.id.close);
                        group = (RadioRealButtonGroup) dialog.findViewById(R.id.mode_group);
                        startDateButton = dialog.findViewById(R.id.custom_start_date);
                        endDateButton = dialog.findViewById(R.id.custom_end_date);
                        startDateText = (TextView) dialog.findViewById(R.id.custom_start_date_text);
                        endDateText = (TextView) dialog.findViewById(R.id.custom_end_date_text);
                        format = new SimpleDateFormat("dd/MM/yyyy");
                        startDateText.setText(format.format(visibleStart.getTime()));
                        endDateText.setText(format.format(visibleEnd.getTime()));
                        rangeLayout = dialog.findViewById(R.id.range_layout);
                    }

                    @Override
                    public void setListeners(final AlertDialog dialog) {
                        closeButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                dialog.dismiss();
                            }
                        });
                        group.setOnClickedButtonListener(new RadioRealButtonGroup.OnClickedButtonListener() {
                            @Override
                            public void onClickedButton(RadioRealButton button, int position) {
                                visibleMode = VisibleMode.values()[position];
                                switch (visibleMode) {
                                    case MONTHLY:
                                        visibleStart = Calendar.getInstance();
                                        visibleStart.set(Calendar.DAY_OF_MONTH, 0);
                                        visibleEnd = Calendar.getInstance();
                                        rangeLayout.setVisibility(View.GONE);
                                        break;
                                    case WEEKLY:
                                        visibleEnd = Calendar.getInstance();
                                        visibleStart = Calendar.getInstance();
                                        visibleStart.set(Calendar.DAY_OF_WEEK, visibleStart.getFirstDayOfWeek());
                                        rangeLayout.setVisibility(View.GONE);
                                        break;
                                    case CUSTOM:
                                        rangeLayout.setVisibility(View.VISIBLE);
                                        break;
                                    default:
                                        rangeLayout.setVisibility(View.GONE);
                                }
                            }
                        });

                        startDateButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this);
                                datePickerDialog.setOnDateSetListener(new DatePickerDialog.OnDateSetListener() {
                                    @Override
                                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                                        visibleStart.set(datePicker.getYear(), datePicker.getMonth(), datePicker.getDayOfMonth());
                                        startDateText.setText(format.format(visibleStart.getTime()));
                                        Log.d("-----", visibleStart.getTime().toString());
                                    }
                                });
                                datePickerDialog.show();
                            }
                        });
                        endDateButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this);
                                datePickerDialog.setOnDateSetListener(new DatePickerDialog.OnDateSetListener() {
                                    @Override
                                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                                        visibleEnd.set(datePicker.getYear(), datePicker.getMonth(), datePicker.getDayOfMonth());
                                        endDateText.setText(format.format(visibleEnd.getTime()));
                                        Log.d("-----", visibleEnd.getTime().toString());
                                    }
                                });
                                datePickerDialog.show();
                            }
                        });
                    }
                });
            }
        });
        scroll2.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View view, int i, int i1, int i2, int i3) {
                if (scroll2Toched)
                    scroll1.scrollTo(i2, i3);

                Log.d("----2", String.valueOf(scroll2Toched));
            }
        });

        scroll1.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View view, int i, int i1, int i2, int i3) {
                if (scroll1Toched)
                    scroll2.scrollTo(i2, i3);
                Log.d("----1", String.valueOf(scroll1Toched));
            }
        });

        scroll2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                    scroll2Toched = true;
                if (motionEvent.getAction() == MotionEvent.ACTION_UP)
                    scroll2Toched = false;
                scroll1.scrollTo(scroll2.getScrollX(), scroll2.getScrollY());
                return false;
            }
        });
        scroll1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                    scroll1Toched = true;
                if (motionEvent.getAction() == MotionEvent.ACTION_UP)
                    scroll1Toched = false;
                scroll2.scrollTo(scroll1.getScrollX(), scroll1.getScrollY());
                return false;
            }

        });

        connectionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bluetoothHelper.isConnected())
                    bluetoothHelper.disconnect();
                else {
                    DialogHelper.with(MainActivity.this).showCustomDialog(R.layout.connection_layout, new DialogHelper.ViewHandler() {
                        public Button connectButton;
                        public SwipeRefreshLayout swipeRefresh;
                        public RecyclerView list;
                        public DeviceAdapter adapter;

                        @Override
                        public void init(AlertDialog dialog) {
                            swipeRefresh = (SwipeRefreshLayout) dialog.findViewById(R.id.device_refresh);
                            list = (RecyclerView) dialog.findViewById(R.id.device_list);
                            list.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                            adapter = new DeviceAdapter(bluetoothHelper.getDevices());
                            list.setAdapter(adapter);
                            connectButton = (Button) dialog.findViewById(R.id.connect_btn);
                        }

                        @Override
                        public void setListeners(final AlertDialog dialog) {
                            swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {

                                @Override
                                public void onRefresh() {
                                    bluetoothHelper.fetchDevices();
                                    adapter = new DeviceAdapter(bluetoothHelper.getDevices());
                                    list.setAdapter(adapter);
                                    swipeRefresh.setRefreshing(false);
                                }
                            });
                            connectButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    BluetoothDevice device = adapter.getSelectedDevice();
                                    if (device != null) {
                                        startLoader();
                                        startConnection(device);
                                        dialog.cancel();
                                    }
                                }
                            });
                        }
                    });
                }
            }
        });
        addStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addStudentDialog();
            }
        });

    }


    private void refresh() {
        fillTable();
    }

    private void startConnection(BluetoothDevice device) {
        bluetoothHelper.connect(device, new BluetoothHelper.BluetoothListener() {
            @Override
            public void onConnect() {
                stopLoader();
                Toast.makeText(MainActivity.this, "Connected", Toast.LENGTH_LONG).show();
                connectionButton.setImageResource(R.drawable.connected);
            }

            @Override
            public void onReceive(final String inData) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        stopLoader();
                        Packet packet = new Packet();
                        if (packet.fromString(inData)) {
                            switch (Integer.parseInt(packet.getAction())) {
                                case BluetoothHelper.ACTION_REGISTER:
                                    showFingerId(packet);
                                    break;
                                case BluetoothHelper.ACTION_READ:
                                    if (currentStudentDialog != null) showFingerId(packet);
                                    markAttendance(packet);
                            }
                        }
                        Log.d("-----", inData);
                    }
                });
            }

            @Override
            public void onDisconnect() {
                connectionButton.setImageResource(R.drawable.disconnected);
            }
        });
    }

    private void markAttendance(Packet packet) {
        if (todayColumnIndex == -1)
            return;
        ArrayList<StudentModel> students = StudentModel.loadAllStudent();
        StudentModel student;
        int pos = 0;
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getFingerPrintId() == Integer.parseInt(packet.getData())) {
                pos = i;
                student = students.get(i);
            }
        }
        TableRow row = (TableRow) attendancePane.getChildAt(pos);
        View cell = row.getChildAt(todayColumnIndex);
        CheckBox checkBox = cell.findViewById(R.id.cell_checkbox);
        checkBox.setChecked(true);
    }

    private void showFingerId(Packet packet) {
        if (currentStudentDialog != null) {
            EditText fingerId = (EditText) currentStudentDialog.findViewById(R.id.finger_id);
            fingerId.setText(packet.getData());
        }
    }

    private void initUI() {
        myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);

        bluetoothHelper = new BluetoothHelper(this);

        scroll1 = (HorizontalScrollView) findViewById(R.id.horiz_scroll_1);
        scroll2 = (HorizontalScrollView) findViewById(R.id.horiz_scroll_2);

        connectionButton = (ImageView) findViewById(R.id.connection_btn);
        refreshButton = (ImageView) findViewById(R.id.refresh_button);
        calenderButton = findViewById(R.id.calender_btn);

        tableHeader = (TableRow) findViewById(R.id.table_header);
        studentPane = (TableLayout) findViewById(R.id.student_pane);
        attendancePane = (TableLayout) findViewById(R.id.attendance_pane);
        addStudent = (FloatingActionButton) findViewById(R.id.fab_student);
        saveAttendace = (FloatingActionButton) findViewById(R.id.save_attendance);

        visibleStart = Calendar.getInstance();
        visibleEnd = Calendar.getInstance();
        visibleStart.set(Calendar.DAY_OF_MONTH, 0);

        fillTable();
    }

    private void fillTable() {
        Calendar cur = Calendar.getInstance();
        cur.setTime(visibleStart.getTime());
        Calendar end = Calendar.getInstance();
        end.setTime(visibleEnd.getTime());
        end.add(Calendar.DATE, 1);
        tableHeader.removeAllViews();
        for (; cur.before(end); cur.add(Calendar.DATE, 1)) {

            View view = LayoutInflater.from(this).inflate(R.layout.day_header, tableHeader, false);
            TextView dayNumField = (TextView) view.findViewById(R.id.day_number);
            TextView dayNameField = (TextView) view.findViewById(R.id.day_name);
            dayNumField.setText("" + cur.get(Calendar.DAY_OF_MONTH));
            dayNameField.setText(cur.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.getDefault()));
            tableHeader.addView(view);
        }

        studentPane.removeAllViews();
        attendancePane.removeAllViews();
        ArrayList<StudentModel> students = StudentModel.loadAllStudent();
        boolean shade = false;
        for (final StudentModel student : students) {
            TableRow row = (TableRow) LayoutInflater.from(this).inflate(R.layout.student_row_layout, tableHeader, false);
            if (shade)
                row.setBackgroundResource(R.color.white_color);
            TextView textView = row.findViewById(R.id.row_student_name);
            row.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    DialogHelper.with(MainActivity.this).confirm("Do you want to delete this student?", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            student.deleteStudent();
                            fillTable();
                        }
                    });
                    return false;
                }
            });
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openStudentUpdate(student);
                    Toast.makeText(getBaseContext(), "click", Toast.LENGTH_LONG).show();
                }
            });
            textView.setText(student.getStudentName());
            studentPane.addView(row);

            cur = Calendar.getInstance();
            cur.setTime(visibleStart.getTime());
            TableRow attendanceRow = new TableRow(this);
            if (shade)
                attendanceRow.setBackgroundResource(R.color.white_color);
            int count = 0;
            todayColumnIndex = -1;
            for (; cur.before(end); cur.add(Calendar.DATE, 1), count++) {
                View cell = LayoutInflater.from(this).inflate(R.layout.attendance_cell_layout, tableHeader, false);
                CheckBox checkBox = cell.findViewById(R.id.cell_checkbox);
                if (!DateUtils.isToday(cur.getTimeInMillis())) {
                    if (!editMode)
                        cell.findViewById(R.id.cell_checkbox).setEnabled(false);
                } else
                    todayColumnIndex = count;
                if(AttendanceModel.findAttendance(""+student.getStudentId(),""+cur.get(Calendar.DAY_OF_MONTH),""+cur.get(Calendar.MONTH),""+cur.get(Calendar.YEAR)))
                    checkBox.setChecked(true);
                else
                    checkBox.setChecked(false);
                attendanceRow.addView(cell);
            }
            attendancePane.addView(attendanceRow);
            shade = !shade;
        }

        scroll1.postDelayed(new Runnable() {
            public void run() {
                scroll1.fullScroll(HorizontalScrollView.FOCUS_RIGHT);
            }
        }, 100L);
        scroll2.postDelayed(new Runnable() {
            public void run() {
                scroll2.fullScroll(HorizontalScrollView.FOCUS_RIGHT);
            }
        }, 100L);
        editMode = false;
    }

    private void openStudentUpdate(final StudentModel student) {
        currentStudentDialog = DialogHelper.with(this).showCustomDialog(R.layout.student_update_layout, new DialogHelper.ViewHandler() {
            public EditText studentRoll;
            public EditText fingerId;
            public Button saveButton;
            public Button cancelButton;
            public Button registerButton;
            public EditText studentName;

            @Override
            public void init(AlertDialog dialog) {
                registerButton = (Button) dialog.findViewById(R.id.register_button);
                cancelButton = (Button) dialog.findViewById(R.id.cancel_button);
                saveButton = (Button) dialog.findViewById(R.id.save_button);
                fingerId = (EditText) dialog.findViewById(R.id.finger_id);
                fingerId.setText(String.valueOf(student.getFingerPrintId()));
                studentName = (EditText) dialog.findViewById(R.id.student_name);
                studentName.setText(student.getStudentName());
                studentRoll = (EditText) dialog.findViewById(R.id.student_roll);
                studentRoll.setText("02211604416");
            }

            @Override
            public void setListeners(final AlertDialog dialog) {
                registerButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Packet packet = new Packet("" + BluetoothHelper.ACTION_REGISTER, "");
                        bluetoothHelper.transmit(packet.toString());
                    }
                });
                cancelButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                saveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        student.setStudentName(studentName.getText().toString());
                        student.setFingerPrintId(Integer.parseInt(fingerId.getText().toString()));
                        student.save();
                        dialog.dismiss();
                    }
                });
            }
        });
    }

    private void addStudentDialog() {

        addStudentDialog = DialogHelper.with(this).showCustomDialog(R.layout.student_add_dialog, new DialogHelper.ViewHandler() {
            public EditText studentName;
            public Button saveButton;
            public Button cancelButton;

            @Override
            public void init(AlertDialog dialog) {
                cancelButton = (Button) dialog.findViewById(R.id.cancel_button);
                saveButton = (Button) dialog.findViewById(R.id.save_button);
                studentName = (EditText) dialog.findViewById(R.id.student_name);
            }

            @Override
            public void setListeners(final AlertDialog dialog) {
                cancelButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                saveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        StudentModel studentModel = new StudentModel();
                        studentModel.setStudentName(studentName.getText().toString());
                        studentModel.addStudent();
                        fillTable();
                        dialog.dismiss();
                    }
                });
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.attendance_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.reset:
                DialogHelper.with(this).confirm("Do you want to reset all fingerprints?", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Packet packet = new Packet("" + BluetoothHelper.ACTION_RESET, "");
                        startLoader();
                        bluetoothHelper.transmit(packet.toString());

                    }
                });
            case R.id.edit_mode:
                editMode = true;
        }
        return super.onOptionsItemSelected(item);
    }
}
