package com.matrixdev.fingerprint.Model;

import com.google.gson.Gson;

public class Packet {
    String action;
    String data;

    public Packet() {
    }

    public Packet(String action, String data) {
        this.action = action;
        this.data = data;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public String toString() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }

    public boolean fromString(String str)
    {
        try {
            Gson gson = new Gson();
            Packet packet=gson.fromJson(str,Packet.class);
            action = packet.action;
            data = packet.data;
            return true;
        }catch (Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
}
