package com.matrixdev.fingerprint.Helpers;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class BluetoothHelper {

    public static final int ACTION_PING = 0;
    public static final int ACTION_REGISTER = 1;
    public static final int ACTION_DELETE = 2;
    public static final int ACTION_LIST = 3;
    public static final int ACTION_RESET = 4;
    public static final int ACTION_READ = 10;
    Activity activity;
    private BluetoothAdapter mBluetoothAdapter;
    private ArrayList<BluetoothDevice> devices;
    private BluetoothDevice mmDevice;
    private BluetoothSocket mmSocket;
    private OutputStream outputStrem;
    private BufferedReader mBufferedInput;

    public BluetoothHelper(Activity activity) {
        this.activity = activity;
        initalize();
    }

    private void initalize() {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            Toast.makeText(activity,"Unable to initalize",Toast.LENGTH_LONG).show();
            Log.d("---", "No Adapter");
        }
        fetchDevices();
    }

    public void fetchDevices() {
        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        devices = new ArrayList<>(pairedDevices);
    }

    public void connect(BluetoothDevice device,BluetoothListener listener)
    {
        mmDevice = device;
        try {
            UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
            mmSocket = mmDevice.createRfcommSocketToServiceRecord(uuid);
            mmSocket.connect();
            outputStrem = mmSocket.getOutputStream();
//            mBufferedOutput = new BufferedWriter(new OutputStreamWriter(mmSocket.getOutputStream()));
            mBufferedInput = new BufferedReader(new InputStreamReader(mmSocket.getInputStream()));
            beginDataInput(listener);

            listener.onConnect();
        } catch (Exception e) {
            listener.onDisconnect();
            e.printStackTrace();
            Log.d("----", e.getMessage());
        }

    }

    private void beginDataInput(final BluetoothListener listener) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.d("----", "Start");
                    while (mmSocket.isConnected()) {
                        final String inData = mBufferedInput.readLine();
                        listener.onReceive(inData);
                        //Log.d("----", inData);
                    }
                } catch (Exception e) {
                    listener.onDisconnect();
                    e.printStackTrace();
                }


            }
        }).start();

    }

    public void transmit(String data)
    {
        if (mmSocket == null || !mmSocket.isConnected())
            return;
        try {
            String cmd = data;
            outputStrem.write(cmd.getBytes());
            outputStrem.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<BluetoothDevice> getDevices() {
        return devices;
    }

    public void setDevices(ArrayList<BluetoothDevice> devices) {
        this.devices = devices;
    }

    public void disconnect() {
        try {
            mmSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public interface BluetoothListener
    {
        public void onConnect();
        public void onReceive(String inData);
        public void onDisconnect();
    }

    public boolean isConnected()
    {
        return mmSocket!=null && mmSocket.isConnected();
    }
}
